<?php get_header(); ?>

<div class="hami-breadcrumb">
    <div class="container">
        <?php
        if (function_exists('hami_breadcrumb')) {
            echo hami_breadcrumb();
        }
        ?>
    </div>
</div>

<div class="container">
    <section class="hero-single">
        <div class="main-single">

            <?php while ( have_posts() ) : the_post(); ?>
            <article class="post-single">
                <header><h1><?php the_title(); ?></h1></header>
                <div class="box-pm">
                    <div class="post-meta">
                        <i class="fa-regular fa-clock"></i>
                        <span><?php the_time('d F Y'); ?></span>
                    </div>
                    <div class="post-meta">
                        <i class="fa-regular fa-user"></i>
                        <span><?php the_author(); ?></span>
                    </div>
                    <div class="post-meta">
                        <i class="fa-regular fa-folder"></i>
                        <?php the_category(' , '); ?>
                    </div>
                </div>
                <figure><?php the_post_thumbnail(); ?></figure>
                <div class="content-single">
                    <?php the_content(); ?>
                </div>
                <div class="post-tag">
                    <span><i class="fa-solid fa-tags"></i> </span>
                    <?php the_tags(); ?>
                </div>
            </article>
            <?php endwhile; ?>

            <?php if ($options['active_related_post']) { ?>
            <div class="post-single">
                <div class="related-head">
                    <h4>مطالب مرتبط</h4>
                </div>
                <div class="owl-carousel owl-theme related-article-slider">

                    <?php
                    $related = get_posts( array(
                        'category__in' => wp_get_post_categories($post->ID),
                        'numberposts' => 5,
                        'post__not_in' => array($post->ID) ) );
                    if( $related ) foreach( $related as $post ) {
                    setup_postdata($post); ?>
                    <div class="item related-item">
                        <figure>
                            <?php
                            if (has_post_thumbnail()) {
                                the_post_thumbnail();
                            }
                            else {
                                ?><img src="<?php echo get_template_directory_uri() . '/img/0.jpg'; ?>"><?php
                            }
                            ?>
                        </figure>
                        <h2>
                            <a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a>
                        </h2>
                        <div class="down">
                            <div class="post-meta"><?php the_time('d F Y'); ?></div>
                            <div class="post-meta"><?php the_author(); ?></div>
                        </div>
                    </div>
                    <?php }
                    wp_reset_postdata(); ?>

                </div>
            </div>
            <?php } ?>

            <?php if ( comments_open() || get_comments_number() ) : ?>
                <div class="comment-box">
                    <?php comments_template(); ?>
                </div>
            <?php endif; ?>
        </div>

        <?php if ( is_active_sidebar( 'hami_blog' ) && $options['sidebar_position_single']!='none' ) { ?>
        <aside class="side-single">
                <?php dynamic_sidebar('hami_blog'); ?>
        </aside>
        <?php if ($options['sidebar_position_single'] == 'right') { ?>
            <style>
                .hero-single {flex-direction: row-reverse;}
            </style>
        <?php } ?>
        <?php } else { ?>
            <style>
                .main-single {
                    width: 100%;
                }
            </style>
        <?php } ?>

    </section>
</div>
<?php get_footer(); ?>