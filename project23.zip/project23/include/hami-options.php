<?php
// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

    //
    // Set a unique slug-like ID
    $prefix = 'options';

    //
    // Create options
    CSF::createOptions( $prefix, array(
        'menu_title' => 'تنظیمات قالب',
        'menu_slug'  => 'hami-options',
        'framework_title' => 'تنظیمات حامی',
        'menu_icon' => 'dashicons-image-filter',
        'footer_text' => 'توسعه داده توسط رضاحیدری'
    ) );


    CSF::createSection( $prefix, array(
        'id' => 'common_options',
        'title'  => 'تنظیمات عمومی',
        'icon' => 'fas fa-home',
    ) );
    CSF::createSection( $prefix, array(
        'title'  => 'همگانی',
        'parent' => 'common_options',
        'fields' => array(
            array(
                'type'    => 'subheading',
                'content' => 'تنظیمات عمومی ',
            ),
            array(
                'id'    => 'logo_width',
                'type'  => 'slider',
                'title' => 'بیشترین پهنای تصویر لوگو (px) ',
                'desc' => 'بیشترین عرض برای تصویر لوگو در سربرگ را تنظیم کنید. به پیکسل',
                'min' => 50,
                'max' => 500,
                'unit' => 'px',
                'default' => '130',
            ),
            array(
                'id'    => 'favicon_option',
                'type'  => 'media',
                'title' => 'تصویر فاوآیکون',
                'subtitle' => 'آپلود تصویر:png, jpg or gif file',
                'default' => array(
                    'url'=> get_template_directory_uri().'/img/fav.png',
                ),
                'preview_size' => 'full',
            ),
            array(
                'id'    => 'container_width',
                'type'  => 'slider',
                'title' => 'عرض محدوده محتوا - کانتینر (px) ',
                'desc' => 'بهترین سایز 1440 پیکسل میباشدل',
                'min' => 1000,
                'max' => 1600,
                'unit' => 'px',
                'default' => '1440',
            ),
            array(
                'id'      => 'main_color',
                'type'    => 'color',
                'title'   => 'رنگ اصلی قالب',
                'subtitle'   => 'رنگ اصلی قالب را انتخاب کنید',
                'default' => '#F93423',
            ),
            array(
                'id'      => 'second_color',
                'type'    => 'color',
                'title'   => 'رنگ مکمل قالب',
                'subtitle'   => 'رنگ مکمل قالب را انتخاب کنید',
                'default' => '#1BD2A3',
            ),
            array(
                'id'    => 'bg_body',
                'type'  => 'background',
                'title' => 'پس زمینه سایت',
                'subtitle' => 'برای بک گراند سایت میتوانید یک رنگ یا تصویر انتخاب کنید - پیشفرض سفید است',
                'default' => array(
                  'background-color' => '#fff',
                ),
                'output' => array('body'),
            ),
        )
    ) );

    CSF::createSection( $prefix, array(
        'id' => 'header_options',
        'title'  => 'سربرگ',
        'icon' => 'fas fa-th-large',
    ) );
    CSF::createSection( $prefix, array(
        'title'  => 'نوار بالا',
        'parent' => 'header_options',
        'fields' => array(
            array(
                'id'         => 'active_topmenu',
                'type'       => 'switcher',
                'title'      => 'نوار بالا',
                'subtitle'      => 'نمایش/عدم نمایش نوار بالا',
                'text_on'    => 'فعال',
                'text_off'   => 'غیرفعال',
                'text_width' => 80,
                'default' => true,
            ),
            array(
                'id'    => 'bg_top_header',
                'type'  => 'background',
                'title' => 'پس زمینه نوار بالا',
                'default' => array(
                    'background-color' => '#fff',
                ),
                'output' => array('.hero-top-header'),
                'dependency' => array( 'active_topmenu', '==', 'true' ),
            ),
            array(
                'id'      => 'color_top_header',
                'type'    => 'color',
                'title'   => 'رنگ متن نوار بالا',
                'default' => '#7E7E7E',
                'output' => array('.top-header'),
                'dependency' => array( 'active_topmenu', '==', 'true' ),
            ),
            array(
                'id'    => 'custom_text_topmenu_right',
                'type'  => 'wp_editor',
                'title' => 'متن دلخواه سمت راست',
                'default' => 'محصولات جدید: لباس های مجلسی شارژ شد یک سر به بخش لباس های مجلسی بزنید',
                'height'        => '80px',
                'dependency' => array( 'active_topmenu', '==', 'true' ),
            ),
            array(
                'id'    => 'custom_text_topmenu_left',
                'type'  => 'wp_editor',
                'title' => 'متن دلخواه سمت چپ',
                'default' => 'اگر سوال یا مشکلی دارید با پشتیبانی تماس بگیرید',
                'height'        => '80px',
                'dependency' => array( 'active_topmenu', '==', 'true' ),
            ),
            array(
                'id'      => 'contact_topmenu_left',
                'type'    => 'text',
                'title'   => 'شماره/اطلاعات تماس',
                'default' => '۷۵۳۶۲۹۸-۰۲۱',
                'dependency' => array( 'active_topmenu', '==', 'true' ),
            ),
            array(
                'id'      => 'icon_topmenu_left',
                'type'    => 'icon',
                'title'   => 'ایکون تماس',
                'default' => 'fas fa-headset',
                'dependency' => array( 'active_topmenu', '==', 'true' ),
            ),
            array(
                'id'         => 'active_topmenu_mobile',
                'type'       => 'switcher',
                'title'      => 'نوار بالا در موبایل',
                'subtitle'      => 'نمایش/عدم نمایش نوار بالا در موبایلا',
                'text_on'    => 'فعال',
                'text_off'   => 'غیرفعال',
                'text_width' => 80,
                'default' => false,
                'dependency' => array( 'active_topmenu', '==', 'true' ),
            ),
        )
    ) );

    CSF::createSection($prefix , array(
        'title'  => 'تنظیمات سربرگ',
        'parent' => 'header_options',
        'fields' => array(
            array(
                'type'    => 'subheading',
                'content' => 'تنظیمات سربرگ ',
            ),
            array(
                'id'          => 'select_header',
                'type'        => 'select',
                'title'       => 'انتخاب سربرگ',
                'subtitle' => 'انتخاب کنید کدام نوع سربرگ می خواهید نمایش داده شود',
                'options'     => array(
                    'one_header'  => 'سربرگ اول',
                    'two_header'  => 'سربرگ دوم',
                ),
                'default'     => 'one_header',
            ),
            array(
                'id'    => 'logo_option',
                'type'  => 'media',
                'title'    => 'تصویر لوگو',
                'subtitle' => 'آپلود تصویر:png, jpg or gif file',
                'default'  => array(
                    'url'=>get_template_directory_uri().'/img/logo.png'
                ),
                'preview_size'  => 'full',
            ),
            array(
                'id'    => 'logo_mobile_option',
                'type'  => 'media',
                'title'    => 'لوگو موبایل',
                'subtitle' => 'آپلود تصویر:png, jpg or gif file',
                'default'  => array(
                    'url'=>get_template_directory_uri().'/img/logo.png'
                ),
                'preview_size'  => 'full',
            ),
            array(
                'id'    => 'active_cart',
                'type'  => 'switcher',
                'title'    => 'نمایش دکمه سبدخرید',
                'subtitle' => 'نمایش/عدم نمایش نوار بالا',
                'default'  => true,
                'text_on'  => 'نمایش',
                'text_off' => 'مخفی',
                'text_width' => 80,
            ),
            array(
                'id'    => 'active_megamenu',
                'type'  => 'switcher',
                'title'    => 'نمایش مگامنو',
                'default'  => true,
                'text_on'  => 'نمایش',
                'text_off' => 'مخفی',
                'text_width' => 80,
            ),
            array(
                'id'      => 'title_megamenu',
                'type'    => 'text',
                'title'    => 'عنوان مگامنو',
                'default'    => 'دسته بندی محصول',
                'dependency' => array( 'active_megamenu', '==', 'true' ),
            ),
            array(
                'id'    => 'active_wishlist',
                'type'  => 'switcher',
                'title'    => 'نمایش دکمه علاقه مندی ها',
                'subtitle'    => 'درصورتی که افزونه علاقه مندها را فعال کرده باشید میتوانید این دکمه را نمایش دهید',
                'description'    => 'اگر این دکمه را غیرفعال کنید میتوانید دکمه دلخواه داشته باشید',
                'default'  => true,
                'text_on'  => 'نمایش',
                'text_off' => 'مخفی',
                'text_width' => 80,
            ),
            array(
                'id'      => 'title_custom_btn',
                'type'    => 'text',
                'title'    => 'عنوان دکمه دلخواه',
                'dependency' => array( 'active_wishlist', '==', 'false' ),
            ),
            array(
                'id'      => 'link_custom_btn',
                'type'    => 'text',
                'title'    => 'لینک دکمه دلخواه',
                'dependency' => array( 'active_wishlist', '==', 'false' ),
            ),
            array(
                'id'    => 'icon_custom_btn',
                'type'  => 'icon',
                'title'    => 'آیکون دکمه دلخواه',
                'default'          => 'far fa-play-circle',
                'dependency' => array( 'active_wishlist', '==', 'false' ),
            ),
            array(
                'type'    => 'subheading',
                'content' => 'تنظیمات زیر منوط به انتخاب سربرگ دوم هستند ',
                'dependency' => array( 'select_header', '==', 'two_header' ),
            ),
            array(
                'id'    => 'active_search',
                'type'  => 'switcher',
                'title'    => 'نمایش دکمه جستجو',
                'default'  => true,
                'text_on'  => 'نمایش',
                'text_off' => 'مخفی',
                'text_width' => 80,
                'dependency' => array( 'select_header', '==', 'two_header' ),
            ),
            array(
                'id'    => 'active_account',
                'type'  => 'switcher',
                'title'    => 'نمایش حساب کاربری',
                'default'  => true,
                'text_on'  => 'نمایش',
                'text_off' => 'مخفی',
                'text_width' => 80,
                'dependency' => array( 'select_header', '==', 'two_header' ),
            ),
            array(
                'id'    => 'bg_header_two',
                'type'  => 'background',
                'title'    => 'رنگ پس زمینه هدر' ,
                'subtitle' => 'پیشفرض سفید است',
                'default'                         => array(
                    'background-color'              => '#353535',
                ),
                'output'    => array('.header-two'),
                'background_size'               => false,
                'background_position'           => false,
                'background_repeat'             => false,
                'background_image'             => false,
                'background_attachment'             => false,
                'dependency' => array( 'select_header', '==', 'two_header' ),
            ),
            array(
                'id'    => 'main_colorcolor_header_two',
                'type'  => 'color',
                'title'    => 'رنگ متن های هدر' ,
                'subtitle' => 'پیشفرض تیره است',
                'default'  => '#fff',
                'output'    => array('.header-two .megamenu-box span.title-megamenu','.header-two .megamenu-box','.header-two .menu-header > ul > li > a','.header-two .m-h-left i','.header-two #hamberger','.header-two .account-btn label'),
                'dependency' => array( 'select_header', '==', 'two_header' ),
            ),
        )
    ));

    CSF::createSection($prefix , array(
        'title'  => 'تایپوگرافی',
        'icon'   => 'fas fa-font',
        'id'    => 'typography_options',
        'fields' => array(
            array(
                'type'    => 'subheading',
                'content' => 'تنظیمات تایپوگرافی ',
            ),
            array(
                'id'      => 'font_body',
                'type'    => 'typography',
                'title'          => 'فونت بدنه سایت',
                'subtitle'       => 'ترجیحا تغییر ندید چون الان در بهترین حالته',
                'output'      => array('body'),
                'default' => array(
                    'color'       => '#303030',
                    'font-family' => 'yekanbakh',
                    'font-size'   => '14',
                    'line-height' => '20',
                    'unit'        => 'px',

                ),
            ),
        )
    ));


    CSF::createSection($prefix , array(
        'title'  => 'نوشته ها',
        'icon'   => 'fas fa-pencil-alt',
        'id'    => 'blog_options',
        'fields' => array(
            array(
                'type'    => 'subheading',
                'content' => 'تنظیمات صفحه داخلی مقالات ',
            ),
            array(
                'id'        => 'sidebar_position_single',
                'type'      => 'image_select',
                'title'     => 'موقعیت سایدبار صفحه نوشته ها',
                'subtitle'     => 'میتوانید سایدبار را سمت چپ/راست قرار دهید یا مخفی کنید',
                'options'   => array(
                    'right' => get_template_directory_uri().'/img/panel/right.png',
                    'none' => get_template_directory_uri().'/img/panel/none.png',
                    'left' => get_template_directory_uri().'/img/panel/left.png',
                ),
                'default'   => 'left'
            ),
            array(
                'id'    => 'active_related_post',
                'type'  => 'switcher',
                'title'    => 'نمایش مطالب مرتبط',
                'default'  => true,
                'text_on'  => 'نمایش',
                'text_off' => 'مخفی',
                'text_width' => 80,
            ),
        )
    ));


    CSF::createSection($prefix , array(
        'title'  => 'اینستاگرام',
        'icon'   => 'fab fa-instagram',
        'id'    => 'instagram_options',
        'fields' => array(
            array(
                'type'    => 'subheading',
                'content' => 'تنظیمات صفحه داخلی پست های اینستاگرام ',
            ),
            array(
                'id'    => 'bg_single_instagram',
                'type'  => 'background',
                'title'    => 'پس زمینه صفحه داخلی اینستاگرام',
                'subtitle' => 'برای بک گراند صفحه داخلی مطالب اینستاگرام یک رنگ یا تصویر انتخاب کنید - پیشفرض تیره است',
                'default'                         => array(
                    'background-color' => '#333',
                ),
                'output'    => array('.single-insta-page'),
            ),
            array(
                'id'    => 'main_colorcolor_single_instagram',
                'type'  => 'color',
                'title' => 'رنگ متن کپشن',
                'subtitle' => 'پیشفرض سفید است',
                'default'  => '#fff',
                'output'    => array('.hero-insta .left p'),
            ),
            array(
                'id'    => 'active_related_post_instagram',
                'type'  => 'switcher',
                'title'    => 'نمایش پست های مرتبط',
                'default'  => true,
                'text_on'  => 'فعال',
                'text_off' => 'غیرفعال',
                'text_width' => 80,
            ),
            array(
                'id'    => 'back_related_single_instagram',
                'type'  => 'background',
                'title'    => 'رنگ پس زمینه باکس پست های مرتبط',
                'subtitle' => 'پیشفرض تیره است',
                'default'                         => array(
                    'background-color' => '#333',
                ),
                'output'    => array('.box-insta-single'),
                'background_size'               => false,
                'background_position'           => false,
                'background_repeat'             => false,
                'background_image'             => false,
                'background_attachment'             => false,
                'dependency' => array( 'active_related_post_instagram', '==', 'true' ),
            ),
            array(
                'id'    => 'related_instagram_img',
                'type'  => 'media',
                'title' => 'تصویر مطالب مرتبط اینستاگرام ',
                'subtitle' => 'آپلود تصویر:png, jpg or gif file',
                'default'  => array(
                    'url'=>get_template_directory_uri().'/img/insta.png'
                ),
                'preview_size'  => 'full',
                'dependency' => array( 'active_related_post_instagram', '==', 'true' ),
            ),
            array(
                'id'      => 'related_instagram_page_link',
                'type'    => 'text',
                'title'    => 'لینک صفحه اینستاگرام ',
                'default'          => '#',
                'dependency' => array( 'active_related_post_instagram', '==', 'true' ),
            ),
        )
    ));

    CSF::createSection($prefix,array(
        'title' => 'تنظیمات محصول',
        'icon'   => 'fas fa-dumpster',
        'id'    => 'product_options',
    ));

    CSF::createSection($prefix,array(
        'title' => 'صفحه محصول',
        'id'    => 'section_product_options',
        'parent' => 'product_options',
        'fields' => array(
            array(
                'type'    => 'subheading',
                'content' => 'تنظیمات صفحه داخلی محصول ',
            ),
            array(
                'id'    => 'active_brand',
                'type'  => 'switcher',
                'title'    => 'نمایش برند محصول',
                'default'  => true,
                'text_on'  => 'فعال',
                'text_off' => 'غیرفعال',
                'text_width' => 80,
            ),
            array(
                'id'    => 'active_category',
                'type'  => 'switcher',
                'title'    => 'نمایش دسته بندی محصول',
                'default'  => true,
                'text_on'  => 'فعال',
                'text_off' => 'غیرفعال',
                'text_width' => 80,
            ),
            array(
                'id'    => 'active_stock',
                'type'  => 'switcher',
                'title'    => 'نمایش موجود در انبار',
                'default'  => true,
                'text_on'  => 'فعال',
                'text_off' => 'غیرفعال',
                'text_width' => 80,
            ),
            array(
                'id'    => 'active_excerpt_content',
                'type'  => 'switcher',
                'title'    => 'نمایش توضیحات کوتاه محصول',
                'default'  => false,
                'text_on'  => 'فعال',
                'text_off' => 'غیرفعال',
                'text_width' => 80,
            ),
            array(
                'id'    => 'active_attr',
                'type'  => 'switcher',
                'title'    => 'نمایش ویژگی های محصول',
                'default'  => true,
                'text_on'  => 'فعال',
                'text_off' => 'غیرفعال',
                'text_width' => 80,
            ),
            array(
                'id'    => 'active_related_product',
                'type'  => 'switcher',
                'title'    => 'نمایش محصولات مرتبط ',
                'default'  => true,
                'text_on'  => 'فعال',
                'text_off' => 'غیرفعال',
                'text_width' => 80,
            ),

            array(
                'type'    => 'subheading',
                'content' => 'تنظیمات نظرات محصول ',
            ),
            array(
                'id'    => 'active_slider_reviews',
                'type'  => 'switcher',
                'title'    => 'نمایش آیتم های اسلایدر در نظرات ',
                'default'  => true,
                'text_on'  => 'نمایش',
                'text_off' => 'مخفی',
                'text_width' => 80,
            ),
            array(
                'id'      => 'review_but',
                'type'    => 'text',
                'title'    => 'عنوان آیتم اول',
                'default'    => 'زیبایی',
                'dependency' => array( 'active_slider_reviews', '==', 'true' ),
            ),
            array(
                'id'      => 'review_power',
                'type'    => 'text',
                'title'    => 'عنوان آیتم دوم',
                'default'    => 'قدرت',
                'dependency' => array( 'active_slider_reviews', '==', 'true' ),
            ),
            array(
                'id'      => 'review_quality',
                'type'    => 'text',
                'title'    => 'عنوان آیتم سوم',
                'default'    => 'کیفیت ساخت',
                'dependency' => array( 'active_slider_reviews', '==', 'true' ),
            ),
            array(
                'id'          => 'review_property',
                'type'        => 'text',
                'title'    => 'عنوان آیتم چهارم',
                'default'    => 'امکانات',
                'dependency' => array( 'active_slider_reviews', '==', 'true' ),
            ),
            array(
                'id'          => 'review_buy',
                'type'        => 'text',
                'title'    => 'عنوان آیتم پنجم',
                'default'    => 'ارزش خرید',
                'dependency' => array( 'active_slider_reviews', '==', 'true' ),
            ),
        )
    ));


    CSF::createSection($prefix,array(
        'title' => 'دکمه ارتباط باما',
        'icon'   => 'fas fa-headphones-alt',
        'id'    => 'contact_us',

        'fields' => array(
            array(
                'type'    => 'subheading',
                'content' => 'دکمه ارتباط با ما (شناور پایین سمت راست) ',
            ),
            array(
                'id'    => 'active_contact_us',
                'type'  => 'switcher',
                'title'    => 'نمایش دکمه در دسکتاپ',
                'default'  => true,
                'text_on'  => 'نمایش',
                'text_off' => 'مخفی',
                'text_width' => 80,
            ),
            array(
                'id'    => 'active_contact_us_mobile',
                'type'  => 'switcher',
                'title'    => 'نمایش دکمه در موبایل',
                'default'  => true,
                'text_on'  => 'نمایش',
                'text_off' => 'مخفی',
                'text_width' => 80,
            ),
            array(
                'id'    => 'background_contact_us',
                'type'  => 'background',
                'title'    => 'رنگ دکمه' ,
                'subtitle' => 'پیشفرض قرمز است',
                'default'                         => array(
                    'background-color'              => '#f93423',
                ),
                'output'    => array('.floating-contact .floating-button'),
                'background_size'               => false,
                'background_position'           => false,
                'background_repeat'             => false,
                'background_image'             => false,
                'background_attachment'             => false,
            ),
            array(
                'type'    => 'subheading',
                'content' => 'هرکدام از موارد زیر را پر کنید نمایش داده میشود',
            ),
            array(
                'id'      => 'contact_tell',
                'type'    => 'text',
                'title'    => 'شماره تماس',
                'default' => '#',
            ),
            array(
                'id'          => 'contact_telegram',
                'type'        => 'text',
                'title'    => 'آیدی تلگرام',
                'default' => '#',
            ),
            array(
                'id'          => 'contact_instagram',
                'type'        => 'text',
                'title'    => 'آیدی اینستاگرام',
                'default' => '#',
            ),
            array(
                'id'          => 'contact_whatsup',
                'type'        => 'text',
                'title'    => 'شماره واتساپ',
                'subtitle'    => 'شماره را در فرمت بین المللی بنویسید ( مثال : 989101234567',
                'default' => '#',
            ),
            array(
                'id'          => 'contact_bale',
                'type'        => 'text',
                'title'    => 'آدرس حساب پیام رسان بله',
                'default' => '#',
            ),
            array(
                'id'          => 'contact_rubika',
                'type'        => 'text',
                'title'    => 'آدرس حساب پیام رسان روبیکا',
                'default' => '#',
            ),
            array(
                'id'          => 'contact_soroush',
                'type'        => 'text',
                'title'    => 'آدرس حساب پیام رسان سروش',
                'default' => '#',
            ),
            array(
                'id'          => 'contact_email',
                'type'        => 'text',
                'title'    => 'ادرس ایمیل',
                'default' => '#',
            ),

        )
    ));

    CSF::createSection($prefix,array(
        'title' => 'تنظیمات فوتر',
        'icon'   => 'fas fa-pallet',
        'id'    => 'footer_options',
    ));
    CSF::createSection($prefix,array(
        'title' => ' فوتر',
        'id'    => 'footer',
        'parent' => 'footer_options',
        'fields' => array(
            array(
                'id'    => 'text_footer_line',
                'type'  => 'wp_editor',
                'title'    => 'محتوای دلخواه (بالای متن کپی رایت نمایش داده میشود)' ,
                'default'          => 'پاسخگویی تلفنی از شنبه تا پنجشنبه ساعت ۹ الی ۲۰     |     شماره تماس : 09151234567     |     websoft3.ir@gmail.com',
                'height' => '80px',
            ),
            array(
                'id'    => 'text_copy_right',
                'type'  => 'wp_editor',
                'title'    => 'متن کپی رایت' ,
                'default'          => 'کلیه حقوق این وب سایت متعلق به فروشگاه حامی می باشد',
                'height' => '80px',
            ),
            array(
                'type'    => 'subheading',
                'content' => 'لینک صفحات اجتماعی  ',
            ),
            array(
                'id'        => 'social_group',
                'type'      => 'group',
                'title'     => 'افزودن شبکه اجتماعی',
                'button_title' => 'افزودن جدید',
                'fields'    => array(
                    array(
                        'id'    => 'text_social',
                        'type'  => 'text',
                        'title' => 'عنوان',
                    ),
                    array(
                        'id'    => 'icon_social',
                        'type'  => 'icon',
                        'title'    => 'آیکون',
                    ),
                    array(
                        'id'    => 'link_social',
                        'type'  => 'text',
                        'title' => 'لینک صفحه',
                    ),
                ),
            ),
        )
    ));
    CSF::createSection($prefix,array(
        'title' => 'اپلیکیشن',
        'id' => 'application',
        'parent' => 'footer_options',
        'fields' => array(
            array(
                'type'    => 'subheading',
                'content' => 'تنظیمات نمایش اپلیکیشن در فوتر ',
            ),
            array(
                'id'    => 'active_application',
                'type'  => 'switcher',
                'title'    => 'نمایش دانلود اپلیکیشن در فوتر ',
                'default'  => true,
                'text_on'  => 'نمایش',
                'text_off' => 'مخفی',
                'text_width' => 80,
            ),
            array(
                'id'    => 'background_application',
                'type'  => 'background',
                'title'    => 'رنگ پس زمینه' ,
                'subtitle' => 'پیشفرض طوسی است',
                'default'                         => array(
                    'background-color'              => '#f3f4f6',
                ),
                'output'    => array('.application'),
                'background_size'               => false,
                'background_position'           => false,
                'background_repeat'             => false,
                'background_image'             => false,
                'background_attachment'             => false,
                'dependency' => array( 'active_application', '==', 'true' ),
            ),
            array(
                'id'    => 'color_application_title',
                'type'  => 'color',
                'title' => 'رنگ متن ',
                'subtitle'    => 'پیشفرض تیره است' ,
                'default'  => '#303030',
                'output'    => array('.application .right'),
                'dependency' => array( 'active_application', '==', 'true' ),
            ),
            array(
                'id'    => 'icon_application',
                'type'  => 'media',
                'title'    => 'آیکون اپلیکیشن',
                'subtitle' => 'آپلود تصویر:png, jpg or gif file',
                'default'  => array(
                    'url'=>get_template_directory_uri().'/img/icon-application.png'
                ),
                'preview_size'  => 'full',
                'dependency' => array( 'active_application', '==', 'true' ),
            ),
            array(
                'type'    => 'subheading',
                'content' => 'هرکدام از موارد زیر را پر کنید نمایش داده میشود ',
            ),
            array(
                'id'          => 'application_play',
                'type'        => 'text',
                'title'    => 'لینک دانلود از گوگل پلی',
                'default'    => '#',
                'dependency' => array( 'active_application', '==', 'true' ),
            ),
            array(
                'id'          => 'application_bazar',
                'type'        => 'text',
                'title'    => 'لینک دانلود ار کافه بازار',
                'default'    => '#',
                'dependency' => array( 'active_application', '==', 'true' ),
            ),
            array(
                'id'          => 'application_myket',
                'type'        => 'text',
                'title'    => 'لینک دانلود از مایکت',
                'default'    => '#',
                'dependency' => array( 'active_application', '==', 'true' ),
            ),
            array(
                'id'          => 'application_sibapp',
                'type'        => 'text',
                'title'    => 'لینک دانلود از سیب اپ',
                'default'    => '#',
                'dependency' => array( 'active_application', '==', 'true' ),
            ),
        )
    ));


    CSF::createSection($prefix,array(
        'title' => 'حساب کاربری',
        'icon'   => 'fas fa-user',
        'id'    => 'myaccount_options',
    ));
    CSF::createSection($prefix,array(
        'title' => 'پیشخوان ووکامرس',
        'icon'   => 'el el-instagram',
        'id'    => 'panel_woocommerece',
        'parent' => 'myaccount_options',
        'fields' => array(
            array(
                'id'    => 'active_register_time',
                'type'  => 'switcher',
                'title'    => 'نمایش تاریخ عضویت',
                'default'  => true,
                'text_on'  => 'نمایش',
                'text_off' => 'مخفی',
                'text_width' => 80,
            ),
            array(
                'id'    => 'active_tital_orders',
                'type'  => 'switcher',
                'title'    => 'نمایش مجموع سفارشات',
                'default'  => true,
                'text_on'  => 'نمایش',
                'text_off' => 'مخفی',
                'text_width' => 80,
            ),
            array(
                'id'    => 'active_total_comments',
                'type'  => 'switcher',
                'title'    => 'نمایش مجموع دیدگاه ها',
                'default'  => true,
                'text_on'  => 'نمایش',
                'text_off' => 'مخفی',
                'text_width' => 80,
            ),
            array(
                'id'       => 'active_total_payment',
                'type'     => 'switcher',
                'title'    => 'نمایش مجموع پرداخت ها',
                'default'  => true,
                'text_on'  => 'نمایش',
                'text_off' => 'مخفی',
                'text_width' => 80,
            ),
            array(
                'id'       => 'active_order_pending',
                'type'     => 'switcher',
                'title'    => ' نمایش سفارشات در انتظار پرداخت',
                'default'  => true,
                'text_on'  => 'نمایش',
                'text_off' => 'مخفی',
                'text_width' => 80,
            ),
            array(
                'id'       => 'active_order_process',
                'type'     => 'switcher',
                'title'    => 'نمایش سفارشات درحال انجام',
                'default'  => true,
                'text_on'  => 'نمایش',
                'text_off' => 'مخفی',
                'text_width' => 80,
            ),
            array(
                'id'       => 'active_order_complete',
                'type'     => 'switcher',
                'title'    => 'نمایش سفارشات تحویل شده',
                'default'  => true,
                'text_on'  => 'نمایش',
                'text_off' => 'مخفی',
                'text_width' => 80,
            ),
            array(
                'id'       => 'active_order_return',
                'type'     => 'switcher',
                'title'    => 'نمایش سفارشات لغو شده',
                'default'  => true,
                'text_on'  => 'نمایش',
                'text_off' => 'مخفی',
                'text_width' => 80,
            ),
            array(
                'id'       => 'active_notif_myaccount',
                'type'     => 'switcher',
                'title'    => 'نمایش اطلاعیه',
                'default'  => true,
                'text_on'  => 'نمایش',
                'text_off' => 'مخفی',
                'text_width' => 80,
            ),
            array(
                'id'        => 'title_notif_myaccount',
                'type'             => 'text',
                'title'    => 'عنوان اطلاعیه' ,
                'placeholder'    => 'تخفیف خرید اول' ,
                'dependency' => array( 'active_notif_myaccount', '==', 'true' ),
            ),
            array(
                'id'        => 'content_notif_myaccount',
                'type'  => 'wp_editor',
                'title'    => 'متن اطلاعیه' ,
                'height' => '80px',
                'dependency' => array( 'active_notif_myaccount', '==', 'true' ),
            ),

        )
    ));
    CSF::createSection($prefix,array(
        'title' => 'ثبت نام / ورود',
        'icon'   => 'el el-instagram',
        'id'    => 'register_login_options',
        'parent' => 'myaccount_options',
        'fields' => array(
            array(
                'id'    => 'login_back',
                'type'  => 'background',
                'title'    => 'پس زمینه صفحه لاگین ' ,
                'output'    => array('.back-register-login'),
            ),
            array(
                'id'    => 'login_logo',
                'type'  => 'media',
                'title'    => 'لوگو فرم لاگین',
                'subtitle' => 'آپلود تصویر:png, jpg or gif file',
                'default'  => array(
                    'url'=>get_template_directory_uri().'/img/logo.png'
                ),
                'preview_size'  => 'full',
            ),
        )
    ));

}