<?php

add_action('wp_head','custom_style');
function custom_style() {
    $options = get_option( 'options' );
    ?>
    <style>
        .m-h-right .logo {
            max-width: <?php echo $options['logo_width']; ?>px;
        }
        .container {
            width: <?php echo $options['container_width']; ?>px;
        }
        :root {
            --main-color : <?php echo $options['main_color']; ?>;
            --second-color : <?php echo $options['second_color']; ?>;
        }
    </style>
    <?php
}
?>


