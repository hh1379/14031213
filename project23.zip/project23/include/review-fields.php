<?php
// remove rating from comment content
remove_action( 'woocommerce_review_before_comment_meta', 'woocommerce_review_display_rating', 10);

add_action('woocommerce_review_before_comment_meta' , 'hami_before_comment_meta');
function hami_before_comment_meta() {
    echo '<div class="right-review">';
    woocommerce_review_display_rating();

    global $comment;
    $recommend = get_comment_meta($comment->comment_ID , 'recommendstatus' , true);
    if ($recommend==1) {
        echo '<div class="show-recommend-status-yes"><span class="recommend-status-yes">خرید این محصول را پیشنهاد میکنم</span></div>';
    }
    if ($recommend==0) {
        echo '<div class="show-recommend-status-no"><span class="recommend-status-no">خرید این محصول را پیشنهاد نمیکنم</span></div>';
    }
}
add_action('woocommerce_review_before_comment_text' , 'hami_before_comment_text');
function hami_before_comment_text() {
    echo '</div>';
}

add_action('woocommerce_review_after_comment_text' , 'hami_after_comment_text');
function hami_after_comment_text() {
    global $comment;
    $but = get_comment_meta($comment->comment_ID , 'range1' , true);
    $power = get_comment_meta($comment->comment_ID , 'range2' , true);
    $quality = get_comment_meta($comment->comment_ID , 'range3' , true);
    $propery = get_comment_meta($comment->comment_ID , 'range4' , true);
    $buy = get_comment_meta($comment->comment_ID , 'range5' , true);
    ?>
    <div class="show-my-rate">
        <div class="rate-item">
            <span>جذابیت</span>
            <div class="rate-content">
                <div class="rate-result" style="width: <?php echo $but;?>%"></div>
            </div>
        </div>
        <div class="rate-item">
            <span>قدرت موتور</span>
            <div class="rate-content">
                <div class="rate-result" style="width: <?php echo $power;?>%"></div>
            </div>
        </div>
        <div class="rate-item">
            <span>کیفیت</span>
            <div class="rate-content">
                <div class="rate-result" style="width: <?php echo $quality;?>%"></div>
            </div>
        </div>
        <div class="rate-item">
            <span>امکانات</span>
            <div class="rate-content">
                <div class="rate-result" style="width: <?php echo $propery;?>%"></div>
            </div>
        </div>
        <div class="rate-item">
            <span>ارزش خرید</span>
            <div class="rate-content">
                <div class="rate-result" style="width: <?php echo $buy;?>%"></div>
            </div>
        </div>
    </div>
    <?php
}


add_action( 'comment_form_top', 'ecommercehints_comment_form_top', 10 );
function ecommercehints_comment_form_top() {
    if (is_product()) { ?>
        <div class="custom-field-review">
            <div class="review-radio-question">
                <header>آیا خرید این محصول را پیشنهاد میکنید؟</header>
                <div class="radio-list">
                    <div class="radio-item">
                        <input type="radio" name="recommendstatus" id="yes_suggest" value="1" checked>
                        <label for="yes_suggest">بله، پیشنهاد میکنم</label>
                    </div>
                    <div class="radio-item">
                        <input type="radio" name="recommendstatus" value="0" id="no_suggest">
                        <label for="no_suggest">خیر، پیشنهاد نمیکنم</label>
                    </div>
                    <div class="radio-item">
                        <input type="radio" name="recommendstatus" value="2" id="idontknow">
                        <label for="idontknow">نظری ندارم</label>
                    </div>
                </div>
            </div>
            <?php $options = get_option( 'options' );
            if ($options['active_slider_reviews']) { ?>
            <div class="rate-list">
                <?php if ($options['review_but']) { ?>
                <div class="rate-item">
                    <b><?php echo $options['review_but']; ?></b>
                    <input type="range" name="range1" min="10" max="100" step="10" value="50">
                </div>
                <?php } ?>
                <?php if ($options['review_power']) { ?>
                <div class="rate-item">
                    <b><?php echo $options['review_power']; ?></b>
                    <input type="range" name="range2" min="10" max="100" step="10" value="50">
                </div>
                <?php } ?>
                <?php if ($options['review_quality']) { ?>
                <div class="rate-item">
                    <b><?php echo $options['review_quality']; ?></b>
                    <input type="range" name="range3" min="10" max="100" step="10" value="50">
                </div>
                <?php } ?>
                <?php if ($options['review_property']) { ?>
                <div class="rate-item">
                    <b><?php echo $options['review_property']; ?></b>
                    <input type="range" name="range4" min="10" max="100" step="10" value="50">
                </div>
                <?php } ?>
                <?php if ($options['review_buy']) { ?>
                <div class="rate-item">
                    <b><?php echo $options['review_buy']; ?></b>
                    <input type="range" name="range5" min="10" max="100" step="10" value="50">
                </div>
                <?php } ?>
            </div>
            <?php } ?>
        </div>
    <?php }
}



add_action( 'comment_post', 'save_review_pros_and_cons');
function save_review_pros_and_cons( $comment_id) {
    if (isset($_POST['recommendstatus'])) {
        $recommendstatus = sanitize_text_field($_POST['recommendstatus']);
        add_comment_meta($comment_id , 'recommendstatus' , $recommendstatus);
    }

    if (isset($_POST['range1'])) {
        $range1 = sanitize_text_field($_POST['range1']);
        add_comment_meta($comment_id , 'range1' , $range1);
    }
    if (isset($_POST['range2'])) {
        $range2 = sanitize_text_field($_POST['range2']);
        add_comment_meta($comment_id , 'range2' , $range2);
    }
    if (isset($_POST['range3'])) {
        $range3 = sanitize_text_field($_POST['range3']);
        add_comment_meta($comment_id , 'range3' , $range3);
    }
    if (isset($_POST['range4'])) {
        $range4 = sanitize_text_field($_POST['range4']);
        add_comment_meta($comment_id , 'range4' , $range4);
    }
    if (isset($_POST['range5'])) {
        $range5 = sanitize_text_field($_POST['range5']);
        add_comment_meta($comment_id , 'range5' , $range5);
    }

}