<?php get_header(); ?>


<div class="single-insta-page">
    <div class="container">
        <div class="hero-insta">
            <div class="right">
                <?php
                $video_box = get_field('select_video');
                $link_video = $video_box['link_video'];
                $upload_video = $video_box['upload_link'];
                $poster = get_the_post_thumbnail_url();

                if (!empty($link_video)) {
                    $attr = array(
                        'src'        => $link_video,
                        'height'     => 650,
                        'width'      => 1120,
                        'poster'     => $poster,
                    );
                    echo wp_video_shortcode($attr);
                }
                elseif (empty($link_video) && !empty($upload_video)) {
                    $attr = array(
                        'src'        => $upload_video,
                        'height'     => 650,
                        'width'      => 1120,
                        'poster'     => $poster,
                    );
                    echo wp_video_shortcode($attr);
                }
                else {
                    the_post_thumbnail();
                }

                ?>
            </div>
            <div class="left">
                <?php while ( have_posts() ) : the_post(); ?>
                <h1><?php the_title(); ?></h1>
                <?php the_content(); ?>
                <?php endwhile; ?>
            </div>
        </div>

        <?php if ($options['active_related_post_instagram']) { ?>
        <section class="hero-product">
            <h4 class="title-insta-single">
                <i class="fa-brands fa-instagram"></i>
                ویدیو های دیگر
            </h4>
            <div class="box-insta box-insta-single">
                <div class="first-item">
                    <a href="<?php echo $options['related_instagram_page_link']; ?>" target="_blank">
                        <figure class="amazing-thumbnail">
                            <?php if ($options['related_instagram_img']['url']) { ?>
                                <img src="<?php echo $options['related_instagram_img']['url']; ?>">
                            <?php } else { ?>
                            <img src="<?php echo get_template_directory_uri() . '/img/insta.png'; ?>">
                            <?php } ?>
                        </figure>
                    </a>
                </div>
                <div class="left-item">
                    <div class="owl-carousel owl-theme insta-slider-single">
                <?php
                global $post;
                $insta_post = new WP_Query(array(
                    'post_type' => 'insta',
                    'posts_per_page' => 6,
                    'no_found_rows' => true,
                    'post__not_in' => [$post->ID],
                ));

                if ($insta_post->have_posts()) {
                    while ($insta_post->have_posts()) : $insta_post->the_post(); ?>
                        <div class="item product-item">
                            <a href="<?php the_permalink(); ?>" target="_blank">
                                <figure>
                                    <?php
                                    if (has_post_thumbnail()) {
                                        the_post_thumbnail();
                                    }
                                    else {
                                        ?><img src="<?php echo get_template_directory_uri() . '/img/i-1.jpg'; ?>"><?php
                                    }
                                    ?>
                                </figure>
                            </a>
                        </div>
                    <?php
                    endwhile;
                    }
                    wp_reset_postdata();
                    ?>
                    </div>
                </div>
            </div>
        </section>
        <?php } ?>
    </div>
</div>

<div class="container">
    <?php if ( comments_open() || get_comments_number() ) : ?>
        <div class="comment-box">
            <?php comments_template(); ?>
        </div>
    <?php endif; ?>
</div>


<?php get_footer(); ?>