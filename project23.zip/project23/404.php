<?php get_header(); ?>

<div class="page-not-fount">
    <div class="btn404">
        <p>صفحه مورد نظر پیدا نشد! آدرس رو اشتباه اومدی..!</p>
        <a href="<?php echo home_url(); ?>" class="button">صفحه اصلی</a>
        <a href="#" class="button">صفحه فروشگاه</a>
    </div>
    <div class="wrapper">
        <img src="<?php echo get_template_directory_uri() . '/img/404.gif' ?>">
    </div>
</div>

<?php get_footer(); ?>