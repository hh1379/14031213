<?php get_header(); ?>

<?php //include 'template/story.php'; ?>

<?php //include 'template/slider.php'; ?>

<?php //include 'template/amazing.php'; ?>

<?php //include 'template/product.php'; ?>



<?php //include 'template/special.php'; ?>



<?php //include 'template/best-sell.php'; ?>


<?php include 'template/blog.php'; ?>


<?php //include 'template/insta.php'; ?>

<?php //include 'template/brand.php'; ?>


<?php //include 'template/service.php'; ?>

<?php get_footer(); ?>