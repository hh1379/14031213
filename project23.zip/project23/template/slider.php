<div class="container">
    <section class="main-slider">
        <div class="owl-carousel owl-theme m-slider">
            <div class="item"><a href="#"><img src="<?php echo get_template_directory_uri() . '/img/1.jpg' ?>"> </a> </div>
            <div class="item"><a href="#"><img src="<?php echo get_template_directory_uri() . '/img/2.jpg' ?>"> </a> </div>
        </div>
    </section>
</div>