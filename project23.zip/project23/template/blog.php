<section class="hero-blog">
    <div class="container">
        <header class="title-pro">
            <h4><a href="#">وبلاگ حامی</a> </h4>
        </header>

        <div class="box-blog">


            <?php
            $big_post = new WP_Query(array(
                'post_type' => 'post',
                'posts_per_page' => 1,
                'no_found_rows' => true,
            ));

            if ($big_post->have_posts()) {
                while ($big_post->have_posts()) : $big_post->the_post(); ?>
                    <div class="big-post">
                        <a href="<?php the_permalink(); ?>" target="_blank">
                            <figure>
                                <?php
                                    if (has_post_thumbnail()) {
                                        the_post_thumbnail('big-post');
                                    }
                                    else {
                                        ?><img src="<?php echo get_template_directory_uri() . '/img/0.jpg'; ?>"><?php
                                    }
                                ?>
                            </figure>
                            <div class="title">
                                <h2><?php the_title(); ?>
                                    <i class="fa-solid fa-arrow-left"></i>
                                </h2>
                            </div>
                        </a>
                    </div>
                <?php
                endwhile;
            }
            wp_reset_postdata();
            ?>


            <div class="small-post">

                <?php
                $small_post = new WP_Query(array(
                    'post_type' => 'post',
                    'posts_per_page' => 4,
                    'no_found_rows' => true,
                    'offset' => 1,
                ));

                if ($small_post->have_posts()) {
                while ($small_post->have_posts()) : $small_post->the_post(); ?>
                <div class="post-item">
                    <a href="<?php the_permalink(); ?>" target="_blank">
                        <figure>
                            <?php
                            if (has_post_thumbnail()) {
                                the_post_thumbnail('small-post');
                            }
                            else {
                                ?><img src="<?php echo get_template_directory_uri() . '/img/0.jpg'; ?>"><?php
                            }
                            ?>
                        </figure>
                        <h2><?php the_title(); ?></h2>
                        <div class="down">
                            <span><?php the_time('d F Y'); ?></span>
                            <i class="fa-solid fa-arrow-left"></i>
                        </div>
                    </a>
                </div>
                <?php
                endwhile;
                }
                wp_reset_postdata();
                ?>

            </div>

        </div>
    </div>
</section>