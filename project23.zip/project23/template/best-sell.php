<section class="hero-sell">
    <div class="container">
        <header class="title-pro">
            <h4><a href="#">پرفروش ترین محصولات</a> </h4>
        </header>
        <div class="box-sell">

            <?php
            global $product;
            $best_sell = new WP_Query(array(
                'post_type' => 'product',
                'posts_per_page' => 1,
                'no_found_rows' => true,
                'meta_key'  => 'total_sales',
                'orderby' => 'meta_value_num',
            ));

            if ($best_sell->have_posts()) {
            while ($best_sell->have_posts()) : $best_sell->the_post(); ?>
            <div class="best-sell">
                <div class="head">
                    <div>
                        <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                            <rect width="28" height="28" fill="url(#pattern0)"/>
                            <defs>
                                <pattern id="pattern0" patternContentUnits="objectBoundingBox" width="1" height="1">
                                    <use xlink:href="#image0_1193_1099" transform="scale(0.0078125)"/>
                                </pattern>
                                <image id="image0_1193_1099" width="128" height="128" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACAEAQAAAA5p3UDAAAAIGNIUk0AAHomAACAhAAA+gAAAIDoAAB1MAAA6mAAADqYAAAXcJy6UTwAAAACYktHRAAAqo0jMgAAAAlwSFlzAAAAYAAAAGAA8GtCzwAAAAd0SU1FB+cKCBIdBK8ybs8AABRPSURBVHja7V1pdFXVFd77JhBimEHEBJkpaEEosyIWBQxFRDCgCMSyKpSullmoWGtFKYqIDG3XoiUCshhKoUCAgmFuEESgCVgFEwzTIlCmkEAEMp6vPw6PN9xz37sveSPvfmuxVjjn3Hv2dM+7d+999iGyYMGCBQsWLFiwYCHcAZGcDJw9C5/g4kVg/Phg82TBJIBJk3yjeEcIAfHUU8HmzYIH+Ef5Nrz1VrD58xe0YBPgCwCTJhHNn++/GWJigs2jvxD2BuB/5d/fCGsDcK/8NWuIoqPZSxC9916w+QokwtYAPCt/5Ejm8vJg0xnqCEsDsJTvO4SdAVjK9y3CygAs5fseYWMAlvL9g7AwAEv5/kPIG4ClfP8ipA3AUr7/EbIGYCk/MAhJA7CUHziEnAG4V/7y5UQjRnijfCA2FqhWLdh8hSpCygAgRo92r/xf/IJZCFP3gqYB8+cTFRQQ3bwJMWcOwBxsHi0YAIiPB27fVsfjP/sM0Ewbq1T+8uX6+zz/vOdrZ8zQXzdjRrDl4y+E0AowbBhRbKy+3fsnn2jZMqLXXtN3/uQnweYy1BA6BoA2bfRtGzb4TPlERBwdHWw2Qw2hYwD0ww+6Ju7Zk/DjH5u52qPyLSgRQgawd6++7cEHiXfvhmjXzt2VUvlLl1rK9x6hYwC8dSvhq6/0He6NwK78n/882CyEI0LGAJiFIE5KIpw6pe9VG4Gl/MojZAyAiIj54kWiXr3MGIF75QOErKxg8xMOCCkDICJiLTfXoxGgQwe3yqfJk4n/8Y8KEQDFyygVFgZbLgEDkJAAdOgAxMUFlQ7RqBFETo7aMVRaariLBxMnSj4q5tABHnsMKC62X1NcDDz6aDBlUWlZIi5O6jQ+3sPA3/0OKC+XjJeVARkZwNtvA02bBoVwt0ZgrHzJS8U9ehB9+kBs2waxbRvQu3cweK+07NC0KfD22xCZmVKXgNTt9OkGF7RpY1e+6olbuRJo0SLgjJgyAmflS34iy6Vrl1fLlsCqVcarZHk5lE43zJ/v+Sm7fRv47W+98cv7hqlGjYCsLGOG9Dt4I80AZPxj+nTjeIrj8zJvnsvFzMCFC+aWWgDYvBmiZs3AMli7NvDnPwP5+XbFHzgAPPusenzkGABErVrA1q3m9Xf+vMsN2rY1f7HNig4eDLQRSFqjo4GEBIjq1d2OixADkMo/fNhr/eGxx4jufQaqomQHDxLNmEF0+bJyZu7enTg1FcI4wALEx0O89hrQo4evGGatrIz5wgXWVJ9rvhJqTAwwcCDECy9AVK3qr3nc0/DUU1J2xm/uEFWqEG/eTNSli3rEpUtEM2aoPawOOgdmztQ/4XPnyr7YWPl+YPCCKD7+WE9Y9eoQH38M3LljH7hoUUAFWOHPwNhY+fVjQ0YGoApT+5P2v/7VPv+dOzKZRf9ZDjFvnvrpLi+H+OQTWyaU/NsVDptggb/8RT/gV79yJqp/f2eFOk7WtaudqM6djd/ap0wJnBAragCjRumvGzUqYHSLqVPVsvv+e6BTJ/u4bt3UD+Xt28DPfubM069/rR/3pz8R2X4C4LkAAvO2bUSDBxOVlDj3aBrRwoVyokGDiNPTiY0+Fz/80FNkL/h44AFzbb4HRPv2xB98oO5t2ZJo3z7gxRfl/xculLJ3RHExYfBg5s8/9zyb1PndG9y8aYZp5rQ0ovff1w3l7t0h5swhWrvWvbCqViUO7E+B18A//0l05Yq94coV2RYA8KJFRFWqGA944AGideuAjz4i7tZN3//++6xt365vV/yEwUHn8tveFZ99ppSPiI4Gjh1DpdCvn79lWSlPIBISgD/8Qf7z4D71Gb3PP185mR47ZvRCrs6PfOMNhwH9+ukHGEfTgFdeMU/Ud9/p280sUZUVaHh9BgLbt+vpPXHC/MP28svG987O1g0Xffs6DKhXz+4vdsQTTyhvKKKjIa5edU9QWhpEjRrASy/p+8rKgIYN/SvQ8DEA4OGH1fIfNEjKUGUcjrhyxfjpf/JJtfzr1iW6+w7AnJdHdOCA/nJ1kUTWysqI9+wxZunbb4mSklgrLCTauJHo+++d+6OiCH36BFvwIQP07UsUFeXclpVFtGkTa4WFhKQkouPHjW+wZw9rZWXqPpUO9+1jvn6dyDEfACtX6gcOG2bkaiXKzFS3FxcTkpKYb90iImIGCJs364ax75xD4Q9VIcotW5gBIiLp9EpK0n+B2aDWhYxkvvKKvmfVKttfdgPgFSv0Xj9mQkoKRP36+rv/739qYlJSWDt50vk2qoTP1q0DINnwACtk4SIz5uxsok8/VV6Pixd1TaJ+fTnedTfU5ctKA2AuKiKaNUtPSPPmRDt32n4zHKaAnhIhCB99pCcwN1c/NiEhMNL1HkBUFMTTT0P07Am4LM1+mVAhC9eADRERZs9Wy92V/rp1iXbuJFLlccyaJXUtoQGaBjFuHMS2bUSTJyvvyB06EA4cgOjc2d5Wu7Z+YEaGTOlyRV6evi2w7lWzkL7/vXulQ2vfPqLdu/0eD2CFLFgvM9bOnydkZOjH1qljp79LF6IvvyTu0EE92ZQpwOefQ4wbB2gaST+zWZSUAAsWAM2aAYsW6fsVKwgZRBtFTo4/ZVphV7AYOVJ/3YgR/qX19Gn9nOoNMcCsWfqxixZJnSxcaJwIosLs2dHEI0eaJ7VKFaKJE4nGjSMUFZHrXlucPau+7uGHdU18+zagaWa3fQUMSjd2y5b+mk4m1ygim4iPV7/5nzunH5ucTDxmjO5LwiOSkzUi+/JhHlFRxIqkUTYKHavectu1kz8r/hNuxaDaQu6fbeUQrVoRDhwgUsRH2KhEvULGHBfnvfKJiOrU0Sp2oRGM4gAG27K5e3fio0fNbNu+3wAxYADR0aPE3burB/Tvr77Sl4EpTdPUL2ht2hDVr0/UqRPR5MkEd04fR+iXeuDJJ+V9jFC9OlFqqr9/Z0MJECNHEm/cqFxFbeDOndWeWMXPqXKS3buJJk2Ssq9fX+rUFXl5GpHic4Nat2bOy2POzGResIC13r2JOncm7NzpflaHr4R7hMyc6Zna6GiiZcsgnnvOl4IORUAkJhIvXSp59jRYJTuj7B8bduwg6tSJtT59mBculDrMyyNS7G3A+fOa2ov0zDOuLcwZGcSJiYRp04hKS9WT9+vn6JMGJk4kNvIkuqJKFeLVqwMVfQsGgPh44lWr3Id8HcC9eztmPEvZJiaqB5eWEk2dStSvH7NKpwo9cEYGASNG6D/Rrl6FME4SkdFAVfACAIYNk8QmJsrPRhWEME5k3LLFN8KuaEaQ/4JIwL/+peb58GEpExVKSmwrIzB8uHpMWRmgcvnenVfExAB5eUpdQdSsqUz1EuPGuWVGTJigJiY7G2LMGGPlAzLnLTYW2LNH3W921QgfA4Do00fJqti9G6hWDfjb34zlVVIiZXrypLrf/clmwPjx+mvu3IGoUePugBUr9ANu3ACM3bVyL0F6OrxGQYEtnRyoU0cezeYKsy+dYWQASlldvAhIj6pM775xw3t5/vvf7qqfyU01N2/qr1u+nOheTuCcOXofc82ahPXrjfLvZZRvwgTvRbFiBWsyHYk5P59ctnRJ9OoF3D/BIrm59Omn9R0TJjAXFBARsXbjBtGKFd7ffMIEW9RQ1yVq1CBev57o7pN+D0IQyZiNzAfQvvmGsGSJ7g7crRvRpk0QtWqpJmDt668Jhw55R7E9EiXvsW4d0XffudyZiV56qTJCDy2oeDlxgjXXXENn2XjGl1+y9t//qnqkzlJTiewZ23akpDCfOEHkFA6ePp1IH1YkfvZZ6awxcFjw3/9unuCSEsLRo/p2hfHdVwkjDulX95CSom87etT4C0uFNWtUrcATTxAfPar+AsvNJbKfg+gQDs7LIxoyRJ100KwZ0YEDwIYNMsXI4TcHRokhKuTksFZcrKd4xw5dG7dv76WUQxiPP65v0/tUmIuK1IUxDODwMMnNoT16AKmpRPv3S525oriYMGQIc36+rcXJGcF88CDw6qvSsly/VTVN7gsYPJhw7RrwxRfSieQ5Pm0n2CijJSuLqLjY+YDGevWAunVtqUvhCqBePX28paiIkJ2tvIAVD4gReMgQYOhQosaNiXr2JKpXz3hwaSnRsGGsOf9k67xRzBs2AIMHyxcSg0AR168vjcFLsHpbOWulpcClS0RNmjj33A8ndqp4uHzZOIfPm8CT6gVahfx8ouRk5q1bXXvUCuGtWwnt26sTRSsBtGhhXFtA0Y4QCxVXjGnTK6SUTfPmvp3/yBGizp1VyidSrAA2sHb+PESvXsTJyYTf/16mhlUSHBdHaNFCnyVMJINCrlCXhZdeyp/+lKhNG2U2DRERevQgXwVx0aMH8Oab6s7bt2UGb3o6a4qfOJSX6+kw2treqpVxn7c0nz5NPHMmYeVK49XG7L1EYiJQWOi9k0IBMW2a/v5NmugHXr/u6uCAqFoVeOst2VcRVNQRZAZ5ecCbb0I4vztJh1lBgV4OjRvr554+3ScyRmGhTwJr0k28apVviLIhO1unWJWPW+ze7UxLrVrS61UZ+NMAbHTv3evqN4HYu1c/8NVXnefVNLkD2JdYtarCRTzkbhVfE2QT0pgxzgLatUs/Zs4cZ+Gkpfl6XjXfv/xl5RncutXRyCHmztXT4vwZCDF2rF9kjZMnK7QLy3PRqKIiYP9+iMWLZaGCBQtkWbVz5zwTlZ8P0aiRZLx9e3UkzHEvfHJypeUgcnKMPJrOfNeuDXHqVOUFP3y4nf4uXRQECQjpH4B45BHlz4QO585JGS9YADFvHsTixcD+/VIX7nj/5BMjft0kJTz0kLo9M5No7lyijRsd88udrbltW+KxY4lef12d/l27NnFaGkTv3sQpKfpPn8xMZsf0Z1W6enk50fr1RGfOeLbmU6eI1q6V/nb3YC4ogOjYkfDyy8Z1DhzRrJncteOaWjdlCtHq1URErB05AnHsmHOqNjNxSgrEwIHEaWlERsZ55w7Rp58SFi9m7dtvleyhWjXpbn7jDaKOHfVMVWgFMIo9v/66+Xs0bQqxc6exaV675mkOiIce0q8QQtgLJQQfwKBB6ie8QQM7H2PGeCcDAGLHDghX34gbOsTo0Z5WIy+YiopSx5/v3HHaIOLxPvLwJs/Lmw2HDzvuxoHo2lU/xt1GyeBAbuV2VaBD6RxERUEcOWJeDvPne3VOkujaVV3CJzu7wrubZF0gFW7cgPAuWAORkuKZ6dJSwHkJA3r31gt2164A69cEf4oXWZcys0DHjsaZVI78qQJF7ubu29c4l6CSxTjU1SUAmfEza5bZotIy6+X4cfec37wJMXasc17h/WEAsqbC2LHq5AxHHD9u9pxDWY3tgw+Ms6+WLas8Y4iNdb905ebKb2d1Aock8oUX3L8LuOLECYihQ+XPUHgbgFz6hw5V/kQYQezYATFggNHDBbRuLWXurrrroUM+K28H0aAB8PXXnim/dAlIT4dYuxbYvl0ajjd71VwFkZMDsWRJ2BqAWLLEfLVzFUpLpQy3b5cyTU+XMvaEY8cgHnzQtwyibl2ZwOhL3Lpl7vs3TA3AIwoKpAx8CLFrl34rvzFMv2UyX79O/NxzRO++K2P3lUV6OtHjjxNatyYsXSrz1CIFQhCWLpW8t29PtG9f5e9ZVER45x3ixERvcigqFC+DaNmSeOZMmUHk7WGM33xDtGQJ4eJF4kcesSeedOkiHSpmkJNjWC0jaBg92vwu4vXrZZiWSKbJ5eYSJyRIx1nbtt7NW1ZGtG4d0TvvMHuRTXQXlQqYQjRuTDx8OOHFF4k7dTLc8YKsLFnyZP9+Qq9exKNGmd4dEzEoLZUHX6any+yeZ54xLqNTWkrIyCBOTSWsXs2aanufOfhs27OsotG6NVHDhtLVW1hIdOkS4cIF1q5elQUPtm2T6UsWjHHuHFH//swnTkA0aEAcH0/UsCGhRg15EvqlS0RZWax5kzxqjIAcpy4ZOXLEUr5ZnD1L6NKFtWvX/D1TgI5++eMfLeV7g6ZNiRU1mf0Av68AQJ06sqqF629+QYEsLm1PUY5M1Kkja/m5RgNLSggNGpiJYIY0IIYM0X+s5ucDqrz1yATQvLnaH+L/3VEB+AlQ1apbs4bZRBw/QsB8+jSR6qRT/z8k/jcAVmW5GhSTimioKq+6bur0PULu7GALgYVlABEOywAiHJYBRDgsA4hwWAYQ4bAMIMJhGUCEwzKACIdPg0FA8+ZEgwYR+vUjbtyY0KiR24LIFjwDt24R5+bKPIG0NKLU1JBzo0P86Ecya9Wo3KkF32LLFohWrYKtd6l8TJ7sviysBf+gpAQwWyPIL4rXNHPbvSz4FWLxYm/2EPrQAD78MNi8W7BBfViXH5WflGRMzJkzEFOnypPCrBfAygKIi4No1w5i2jTg7Fm1zIWQpf0CQZCIiQHOnFETMXu238/Yi2BAxMQYH/N3+nRAZG98ToDDefQW/Aq5GqgWAvdnPPhmchw6pJ95w4ZgCyXSAGzapDeAgwf9PGlCgrpcy/1T2z9cADz6qF4X5eWAyVPFKjbpwIF6q7PtcbMQaEBkZur1MWCAN/fw7vtRZV2sOMzYQoDwn//omti7U9e8dCCoig5cvRpsMUQsVEf1wl6ZzAy8MwBWbQVXF3S2EAgoZM/ebde3wsERDssAIhyWAUQ4LAOIcPjAAN59tyLxK9+iuBhi507VIQw2yJqD8+fLwyaysoD+/d1xBdGkiay4VVwcbO6MIAt2BRCVPkzB3xCK4+fu0f6b3ziP/eEHx2LOegOoSNm3UIB3x9x6uQL4ojycH8EGh1sSEVG3bs5j4+LU5/nZ+l3Ghw2805GXnsAvvgg2e+7p++or406XPty6RaQ+dtXzvUIVgG9qDrqdYvx49zVqg4HiYllO1cM7gJg3z7t3gB07QvkdwBkXLgQkHGzBggULFixYsGAh/PF/SG+C6dgv/SMAAAAASUVORK5CYII="/>
                            </defs>
                        </svg>
                        <p>پرفروش ترین</p>
                    </div>
                    <span>#۱</span>
                </div>
                <figure>
                    <a href="<?php the_permalink(); ?>" target="_blank">
                        <?php
                        if (has_post_thumbnail()) {
                            the_post_thumbnail('product');
                        }
                        else {
                            ?><img src="<?php echo get_template_directory_uri() . '/img/0.jpg'; ?>"><?php
                        }
                        ?>
                    </a>
                </figure>
                <h2>
                    <a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a>
                </h2>

                <?php if ($product->is_in_stock() && $product->get_price_html()) { ?>
                    <div class="price">
                        <?php echo $product->get_price_html(); ?>
                    </div>
                <?php }
                elseif (!$product->is_in_stock()) {
                    echo "<div class='not_stock'><i class='fa-solid fa-multiply'></i> موجود نیست !</div>";
                }
                else {
                    echo "<div class='contact-us-price'>تماس بگیرید</div>";
                }
                ?>

                <div class="add-cart">
                    <a href="<?php the_permalink(); ?>"><i class="fa-solid fa-circle-plus"></i> </a>
                </div>
            </div>
            <?php
            endwhile;
            }
            wp_reset_postdata();
            ?>

            <div class="other-sell">

                <?php
                $n = 1;
                $other_sell = new WP_Query(array(
                    'post_type' => 'product',
                    'posts_per_page' => 9,
                    'no_found_rows' => true,
                    'meta_key'  => 'total_sales',
                    'orderby' => 'meta_value_num',
                    'offset' => 1,
                ));

                if ($other_sell->have_posts()) {
                while ($other_sell->have_posts()) : $other_sell->the_post(); ?>
                <div class="product-item">
                    <figure>
                        <a href="<?php the_permalink(); ?>" target="_blank">
                            <?php
                            if (has_post_thumbnail()) {
                                the_post_thumbnail('product');
                            }
                            else {
                                ?><img src="<?php echo get_template_directory_uri() . '/img/0.jpg'; ?>"><?php
                            }
                            ?>
                        </a>
                    </figure>
                    <h2>
                        <a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a>
                    </h2>
                    <div class="down">
                        <span class="number">
                            <?php
                            $n = $n + 1;
                            echo $n;
                            ?>
                        </span>
                        <?php if ($product->is_in_stock() && $product->get_price_html()) { ?>
                            <div class="price">
                                <?php echo $product->get_price_html(); ?>
                            </div>
                        <?php }
                        elseif (!$product->is_in_stock()) {
                            echo "<div class='not_stock'><i class='fa-solid fa-multiply'></i> موجود نیست !</div>";
                        }
                        else {
                            echo "<div class='contact-us-price'>تماس بگیرید</div>";
                        }
                        ?>
                    </div>
                </div>
                <?php
                endwhile;
                }
                wp_reset_postdata();
                ?>

            </div>
        </div>
    </div>
</section>