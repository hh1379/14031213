<section class="hero-product">
    <div class="container">
        <div class="hami-service">
            <div class="service-item">
                <img src="<?php echo get_template_directory_uri() . '/img/service/s1.png'; ?>">
                <b>پرداخت امن و مطمئن</b>
                <span>درگاه پرداخت امن و دارای مجوز اینماد</span>
            </div>
            <div class="service-item">
                <img src="<?php echo get_template_directory_uri() . '/img/service/s2.png'; ?>">
                <b>ارسال رایگان</b>
                <span>سفارش بالای ۳۰۰ هزار تومان</span>
            </div>
            <div class="service-item">
                <img src="<?php echo get_template_directory_uri() . '/img/service/s3.png'; ?>">
                <b>گارانتی سلامت محصول</b>
                <span>در صورت معیوب بودن محصول</span>
            </div>
            <div class="service-item">
                <img src="<?php echo get_template_directory_uri() . '/img/service/s4.png'; ?>">
                <b>۷ روز ضمانت بازگشت</b>
                <span>در صورت معیوب بودن محصول</span>
            </div>
            <div class="service-item">
                <img src="<?php echo get_template_directory_uri() . '/img/service/s5.png'; ?>">
                <b>پشتیبانی آنلاین و تلفنی</b>
                <span>جهت مشاوره خرید محصول و سوالات</span>
            </div>
        </div>
    </div>
</section>