<section class="hero-special">
    <div class="container">
        <div class="special-box">
            <h4>محصولات ویژه</h4>
            <div class="owl-carousel owl-theme special-slider">


                <?php
                global $product;
                $new_product = new WP_Query(array(
                    'post_type' => 'product',
                    'posts_per_page' => 5,
                    'no_found_rows' => true,
                    'post__in' => array(231,228,175,228,167),
                ));

                if ($new_product->have_posts()) {
                while ($new_product->have_posts()) : $new_product->the_post(); ?>
                <div class="item special-item" data-dot="<button>
                    <div class='list-special'><figure><img src='<?php echo get_the_post_thumbnail_url(); ?>'></figure>
                    <b><?php the_title(); ?></b></div></button>">

                    <?php if ($product->is_on_sale()) : ?>
                        <div class="discount">
                            <b><?php echo hami_wooocmmerce_discount(get_the_ID()); ?>%</b>
                            <span>تخفیف</span>
                        </div>
                    <?php endif; ?>

                    <figure>


                        <?php
                        global $product;
                        $attr_taxonomy = wc_get_attribute_taxonomies();
                        foreach ($attr_taxonomy as $item) {
                            $attr_name = $item->attribute_name;
                            $terms = get_the_terms($product->ID, 'pa_' . $attr_name);
                            if (is_array($terms)) {
                                ?>
                                <div class="color">
                                    <ul>
                                        <?php
                                        foreach ($terms as $term) {
                                            $tooltip = $term->name;
                                            $colors = get_term_meta($term->term_id, 'product_attribute_color', 1);
                                            ?>
                                            <li>
                                                <?php if ($colors) { ?>
                                                    <span style="background: <?php echo $colors; ?>"><b><?php echo $tooltip; ?></b></span>
                                                <?php } else {
                                                    ?><small><?php echo $tooltip; ?></small><?php
                                                }?>
                                            </li>
                                            <?php
                                        }
                                        ?>
                                    </ul>
                                </div>
                                <?php
                            }
                        }
                        ?>


                        <a href="<?php the_permalink(); ?>" target="_blank">
                            <?php
                            if (has_post_thumbnail()) {
                                the_post_thumbnail('product');
                            }
                            else {
                                ?><img src="<?php echo get_template_directory_uri() . '/img/0.jpg'; ?>"><?php
                            }
                            ?>
                        </a>
                    </figure>
                    <div class="det-special">
                        <h2>
                            <a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a>
                        </h2>

                        <?php do_action( 'woocommerce_product_additional_information', $product ); ?>

                        <div class="down">
                            <a href="<?php the_permalink(); ?>" target="_blank">مشاهده محصول</a>


                            <?php if ($product->is_in_stock() && $product->get_price_html()) { ?>
                                <div class="price">
                                    <?php echo $product->get_price_html(); ?>
                                </div>
                            <?php }
                            elseif (!$product->is_in_stock()) {
                                echo "<div class='not_stock'><i class='fa-solid fa-multiply'></i> موجود نیست !</div>";
                            }
                            else {
                                echo "<div class='contact-us-price'>تماس بگیرید</div>";
                            }
                            ?>

                            <?php include get_template_directory() . '/template/timer.php'; ?>

                        </div>

                    </div>
                </div>

                <?php
                endwhile;
                }
                wp_reset_postdata();
                ?>

            </div>
        </div>
    </div>
</section>