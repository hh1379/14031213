<?php global $product; ?>
<div class="product-action">
    <div class="item-action">
        <button class="woocommerce-product-gallery__trigger">
            <i class="fa-brands fa-sistrix"></i>
            <span>بزرگ نمایی محصول</span>
        </button>
    </div>

    <div class="item-action">
        <?php
        $id = $product->ID;
        ?>
        <?php echo do_shortcode("[woosw id=$id]"); ?>
    </div>
    <div class="item-action" id="btn_modal_share">
        <button>
            <i class="fa-solid fa-share-alt"></i>
            <span>اشتراک گذاری محصول</span>
        </button>
    </div>
    <?php if (get_field('product_video')) : ?>
    <div class="item-action" id="btn_modal_video">
        <button>
            <i class="fa-regular fa-circle-play"></i>
            <span>ویدیو محصول</span>
        </button>
    </div>
    <?php endif; ?>
</div>





<!-- The Modal video -->
<div id="modal_video" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <i class="fa-solid fa-xmark close_video"></i>
            <h4>ویدیو محصول</h4>
        </div>
        <div class="modal-body">
            <video controls>
                <source src="<?php the_field('product_video'); ?>" type="video/mp4">
            </video>
        </div>
    </div>
</div>

<!-- The Modal share -->
<div id="modal_share" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <i class="fa-solid fa-xmark close_share"></i>
            <h4>اشتراک گذاری محصول</h4>
        </div>
        <div class="modal-body">
            <div class="shortlink">
                <span><i class="fa-solid fa-link"></i> لینک کوتاه محصول </span>
                <textarea readonly><?php echo home_url() . "/?p=" . $product->id; ?></textarea>
            </div>
            <div class="social-sharing">
                <p>این پست را به اشتراک بگذارید</p>
                <div class="box-sharing">
                    <a href="https://www.facebook.com/sharer.php?u=<?php the_permalink();?>&t=<?php the_title(); ?>" target="_blank" class="facebook">
                        <i class="fa-brands fa-facebook-square"></i>
                    </a>
                    <a href="https://twitter.com/home?status=Reading: <?php the_permalink(); ?>" target="_blank" class="twitter">
                        <i class="fa-brands fa-twitter-square"></i>
                    </a>
                    <a href="https://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&media=<?php $url = wp_get_attachment_url( get_post_thumbnail_id($product->id) ); echo $url; ?>" target="_blank" class="pinterest">
                        <i class="fa-brands fa-pinterest-square"></i>
                    </a>
                    <a href="https://t.me/share/url?url=<?php the_permalink(); ?>&amp;title=<?php the_title(); ?>" target="_blank" class="telegram">
                        <i class="fa-brands fa-telegram"></i>
                    </a>
                    <a href="https://whatsapp://send?text=<?php the_permalink(); ?>" target="_blank" class="whatsapp">
                        <i class="fa-brands fa-whatsapp-square"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>