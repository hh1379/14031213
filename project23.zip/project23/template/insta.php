<section class="hero-product">
    <div class="container">
        <div class="box-insta">
            <div class="first-item">
                <a href="#" target="_blank">
                    <figure class="amazing-thumbnail">
                        <img src="<?php echo get_template_directory_uri() . '/img/insta.png'; ?>">
                    </figure>
                </a>
            </div>
            <div class="left-item">
                <div class="owl-carousel owl-theme insta-slider">

                    <?php
                    $insta_post = new WP_Query(array(
                        'post_type' => 'insta',
                        'posts_per_page' => 6,
                        'no_found_rows' => true,
                    ));

                    if ($insta_post->have_posts()) {
                    while ($insta_post->have_posts()) : $insta_post->the_post(); ?>
                    <div class="item product-item">
                        <a href="<?php the_permalink(); ?>" target="_blank">
                            <figure>
                                <?php
                                if (has_post_thumbnail()) {
                                    the_post_thumbnail();
                                }
                                else {
                                    ?><img src="<?php echo get_template_directory_uri() . '/img/i-1.jpg'; ?>"><?php
                                }
                                ?>
                            </figure>
                        </a>
                    </div>
                    <?php
                    endwhile;
                    }
                    wp_reset_postdata();
                    ?>

                </div>
            </div>
        </div>
    </div>
    </div>
</section>