<div id="stories" class="hami-story"></div>

<script src="<?php echo get_template_directory_uri() . '/js/zuck.js'; ?>"></script>
<script src="<?php echo get_template_directory_uri() . '/js/script.js'; ?>"></script>

<script>
    var currentSkin = getCurrentSkin();
    var stories = window.Zuck(document.querySelector('#stories'), {
        backNative: true,
        previousTap: true,
        skin: currentSkin['name'],
        autoFullScreen: currentSkin['params']['autoFullScreen'],
        avatars: currentSkin['params']['avatars'],
        paginationArrows: currentSkin['params']['paginationArrows'],
        list: currentSkin['params']['list'],
        cubeEffect: currentSkin['params']['cubeEffect'],
        localStorage: true,
        stories: [
            {
                id: 'ramon',
                photo:
                    '<?php echo get_template_directory_uri() . '/img/1-1.jpg'; ?>',
                name: 'حامی',
                time: timestamp(),
                items: [
                    {
                        id: 'ramon-1',
                        type: 'photo',
                        length: 5000,
                        src: '<?php echo get_template_directory_uri() . '/img/2-1.jpg'; ?>',
                        preview:
                            '<?php echo get_template_directory_uri() . '/img/2-1.jpg'; ?>',
                        link: 'https://websoft3.com',
                        linkText: "کلیک کنید",
                        time: timestamp()
                    },
                    {
                        id: 'ramon-2',
                        type: 'photo',
                        length: 0,
                        src: '<?php echo get_template_directory_uri() . '/img/2-6.jpg'; ?>',
                        preview:
                            '<?php echo get_template_directory_uri() . '/img/2-6.jpg'; ?>',
                        link: '',
                        linkText: false,
                        time: timestamp()
                    },
                    {
                        id: 'ramon-3',
                        type: 'photo',
                        length: 3,
                        src: '<?php echo get_template_directory_uri() . '/img/2-7.jpg'; ?>',
                        preview:
                            '<?php echo get_template_directory_uri() . '/img/2-7.jpg'; ?>',
                        link: 'https://websoft3.com',
                        linkText: 'لینک زیر کلیک کنید',
                        time: timestamp()
                    }
                ]
            },
            {
                id: 'gorillaz',
                photo:
                    '<?php echo get_template_directory_uri() . '/img/1-3.jpg'; ?>',
                name: 'قهوه',
                time: timestamp(),
                items: [
                    {
                        id: 'gorillaz-1',
                        type: 'photo',
                        length: 0,
                        src: '<?php echo get_template_directory_uri() . '/img/2-8.jpg'; ?>',
                        preview:
                            '<?php echo get_template_directory_uri() . '/img/2-8.jpg'; ?>',
                        link: '',
                        linkText: false,
                        time: timestamp()
                    },
                    {
                        id: 'gorillaz-2',
                        type: 'photo',
                        length: 3,
                        src: '<?php echo get_template_directory_uri() . '/img/2-2.jpg'; ?>',
                        preview:
                            '<?php echo get_template_directory_uri() . '/img/2-2.jpg'; ?>',
                        link: '',
                        linkText: false,
                        time: timestamp()
                    }
                ]
            },
            {
                id: 'ladygaga',
                photo:
                    '<?php echo get_template_directory_uri() . '/img/1-4.jpg'; ?>',
                name: 'گوددی',
                time: timestamp(),
                items: [
                    {
                        id: 'ladygaga-1',
                        type: 'photo',
                        length: 5,
                        src: '<?php echo get_template_directory_uri() . '/img/2-5.png'; ?>',
                        preview:
                            'h<?php echo get_template_directory_uri() . '/img/2-5.png'; ?>',
                        link: '',
                        linkText: false,
                        time: timestamp()
                    },
                    {
                        id: 'ladygaga-2',
                        type: 'photo',
                        length: 3,
                        src: '<?php echo get_template_directory_uri() . '/img/2-9.jpg'; ?>',
                        preview:
                            '<?php echo get_template_directory_uri() . '/img/2-9.jpg'; ?>',
                        link: 'http://websoft3.com',
                        linkText: 'سایت وبسافت3',
                        time: timestamp()
                    }
                ]
            },
            {
                id: 'starboy',
                photo:
                    '<?php echo get_template_directory_uri() . '/img/1-5.png'; ?>',
                name: 'کاپوچینو',
                time: timestamp(),
                items: [
                    {
                        id: 'starboy-1',
                        type: 'photo',
                        length: 5,
                        src: '<?php echo get_template_directory_uri() . '/img/2-10.jpg'; ?>',
                        preview:
                            '<?php echo get_template_directory_uri() . '/img/2-10.jpg'; ?>',
                        link: '',
                        linkText: false,
                        time: timestamp()
                    }
                ]
            },
            {
                id: 'riversquomo',
                photo:
                    '<?php echo get_template_directory_uri() . '/img/1-6.png'; ?>',
                name: 'کافی شاپ',
                time: timestamp(),
                items: [
                    {
                        id: 'riverscuomo-1',
                        type: 'photo',
                        length: 10,
                        src: '<?php echo get_template_directory_uri() . '/img/2-5.png'; ?>',
                        preview:
                            '<?php echo get_template_directory_uri() . '/img/2-5.png'; ?>',
                        link: '',
                        linkText: false,
                        time: timestamp()
                    }
                ]
            },
            {
                id: 'hami-1',
                photo:
                    '<?php echo get_template_directory_uri() . '/img/1-2.jpg'; ?>',
                name: 'جدید',
                time: timestamp(),
                items: [
                    {
                        id: 'hami-1-2',
                        type: 'photo',
                        length: 5,
                        src: '<?php echo get_template_directory_uri() . '/img/2-3.jpg'; ?>',
                        preview:
                            '<?php echo get_template_directory_uri() . '/img/2-3.jpg'; ?>',
                        link: '#',
                        linkText: "کلیک کنید",
                        time: timestamp()
                    },
                    {
                        id: 'hami-1-3',
                        type: 'photo',
                        length: 5,
                        src: '<?php echo get_template_directory_uri() . '/img/2-4.png'; ?>',
                        preview:
                            '<?php echo get_template_directory_uri() . '/img/2-4.png'; ?>',
                        link: '#',
                        linkText: "کلیک کنید",
                        time: timestamp()
                    }
                ]
            },
        ]
    });
</script>