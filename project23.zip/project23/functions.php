<?php

add_action( 'wp_enqueue_scripts', 'add_theme_scripts' );
function add_theme_scripts(){
    wp_enqueue_style( 'all', get_template_directory_uri() . '/css/all.css', array(), false , 'all' );
    wp_enqueue_style( 'owl.carousel', get_template_directory_uri() . '/css/owl.carousel.min.css', array(), false , 'all' );
    wp_enqueue_style( 'owl.theme', get_template_directory_uri() . '/css/owl.theme.default.min.css', array(), false , 'all' );
    wp_enqueue_style( 'zuck', get_template_directory_uri() . '/css/zuck.css', array(), false , 'all' );
    wp_enqueue_style( 'snapgram', get_template_directory_uri() . '/css/snapgram.css', array(), false , 'all' );
    wp_enqueue_style('style' , get_stylesheet_uri() );
    wp_enqueue_style( 'responsive', get_template_directory_uri() . '/css/responsive.css', array(), false , 'all' );


    wp_enqueue_script( 'owl.carousel', get_template_directory_uri() . '/js/owl.carousel.min.js', array('jquery'), false , true );
    wp_enqueue_script( 'main', get_template_directory_uri() . '/js/main.js', array('jquery'), false , true );
}

add_action( 'admin_enqueue_scripts', 'admin_custom_style' );
function admin_custom_style() {
    wp_enqueue_style( 'admin-style', get_template_directory_uri() . '/css/admin-style.css', array(), false , 'all' );
}

add_action('after_setup_theme' , 'hami_setup_theme');
function hami_setup_theme() {
    add_theme_support('title-tag');
    add_theme_support( 'automatic-feed-links' );
    add_theme_support('post-thumbnails');
    add_theme_support('woocommerce');
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );


    add_image_size('big-post',588, 300 , true);
    add_image_size('small-post',125, 125 , true);
    add_image_size('product',200, 200 , true);
    add_image_size('cross_img',135, 135 , true);

    register_nav_menus(
        array(
            'main-menu' => __( 'جایگاه نمایش منوی اصلی' ),
            'mega-menu' => __( 'جایگاه نمایش مگامنو' ),
        )
    );
}

// ثبت پست تایپ اینستاگرام
add_action( 'init', 'post_type_instagram' );
function post_type_instagram() {
    $labels = array(
        'name'               => __( 'اینستاگرام' ),
        'singular_name'      => __( 'اینستاگرام' ),
        'menu_name'          => __( 'اینستاگرام' ),
        'name_admin_bar'     => __( 'اینستاگرام' ),
        'add_new'            => __( ' افزودن جدید' ),
        'add_new_item'       => __( 'پست های اینستاگرام' ),
        'new_item'           => __( 'پست جدید' ),
        'edit_item'          => __( 'ویرایش پست' ),
        'view_item'          => __( 'مشاهده پست' ),
        'all_items'          => __( 'همه پست ها' ),
        'search_items'       => __( 'جستجو در بین پست ها' ),
        'parent_item_colon'  => __( 'مادر' ),
        'not_found'          => __( 'مطلب یافت نشد' ),
        'not_found_in_trash' => __( 'مطلب در زباله دان یافت نشد' )
    );
    $args = array(
        'labels'             => $labels,
        'description'        => __( 'Description.', 'your-plugin-textdomain' ),
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,

        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'taxonomies' => array('post_tag'),
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'comments', 'excerpt' ),
    );
    register_post_type( 'insta', $args );
}





// اضافه کردن تاکسونومی برای پست تایپ اینستا
add_action( 'init', 'create_taxonomies_for_insta');
function create_taxonomies_for_insta() {
    $labels = array(
        'name'              => _x( 'دسته بندی', 'دسته بندی' ),
        'singular_name'     => _x( 'دسته بندی پست ها ', 'دسته بندی' ),
        'search_items'      => __( 'جستجویه دسته' ),
        'all_items'         => __( 'تمام دسته ها' ),
        'parent_item'       => __( 'زیر دسته' ),
        'parent_item_colon' => __( 'Parent Genre:' ),
        'edit_item'         => __( 'ویرایش دسته' ),
        'update_item'       => __( 'بروزرسانی دسته' ),
        'add_new_item'      => __( 'افزودن دسته جدید' ),
        'new_item_name'     => __( 'نام جدید دسته' ),
        'menu_name'         => __( 'دسته بندی' ),
    );

    $ar = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
    );

    register_taxonomy( 'cat_hami_insta', 'insta' , $ar );
}



function hami_sidebar() {
    register_sidebar( array(
        'name'          => __( 'ناحیه کناری بلاگ' ),
        'id'            => 'hami_blog',
        'before_widget' => '<div class="widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<div class="widget-header"><h3>',
        'after_title'   => '</h3></div>',
    ) );
    register_sidebar( array(
        'name'          => __( 'ناحیه کناری صفحه فروشگاه' ),
        'id'            => 'hami_shop',
        'before_widget' => '<div id="%1$s" class="%2$s widget"><div class="widget-shop">',
        'after_widget'  => '</div></div>',
        'before_title'  => '<div class="widget-header"><h3>',
        'after_title'   => '</h3></div>',
    ) );

    register_sidebar( array(
        'name'          => __( 'فوتر 1' ),
        'id'            => 'hami_footer_one',
        'before_widget' => '<div class="f-w-contet">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          => __( 'فوتر 2' ),
        'id'            => 'hami_footer_two',
        'before_widget' => '<div class="f-w-contet">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          => __( 'فوتر 3' ),
        'id'            => 'hami_footer_three',
        'before_widget' => '<div class="f-w-contet">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          => __( 'فوتر 4' ),
        'id'            => 'hami_footer_four',
        'before_widget' => '<div class="f-w-contet">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) );
}
add_action( 'widgets_init', 'hami_sidebar' );


//ajax add-to-cart
add_filter('woocommerce_add_to_cart_fragments', function ($fragments) {
    ob_start();
    ?>
    <span class="cart-btn-num">
        <?php echo WC()->cart->get_cart_contents_count(); ?>
    </span>
    <?php $fragments['.cart-btn-num'] = ob_get_clean();
    return $fragments;
});
add_filter('woocommerce_add_to_cart_fragments', function ($fragments) {
    ob_start();
    ?>
    <div class="cart-content">
        <?php woocommerce_mini_cart(); ?>
    </div>
    <?php $fragments['.cart-content'] = ob_get_clean();
    return $fragments;
});


// حذف تگ های ابتدای صفحه داخلی محصول
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);

// اضافه کردن تگ کانتینر به محتوای صفحه داخلی محصول
add_action('woocommerce_before_main_content', 'my_theme_wrapper_start', 10);
add_action('woocommerce_after_main_content', 'my_theme_wrapper_end', 10);
function my_theme_wrapper_start() {
    echo '<div class="container">';
}
function my_theme_wrapper_end() {
    echo '</div>';
}

// حذف سایدبار صفحه داخلی محصول
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10);
// حذف عبارت حراج در صفحه داخلی محصول
remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10);


add_action('woocommerce_before_quantity_input_field', 'hami_before_quantity_input_field');
add_action('woocommerce_after_quantity_input_field', 'hami_after_quantity_input_field');
function hami_before_quantity_input_field() {
    echo '<button class="plus" type="button">+</button>';
}
function hami_after_quantity_input_field() {
    echo '<button class="minus" type="button">-</button>';
}


// discount
function hami_wooocmmerce_discount ($id) {
    $product = wc_get_product( $id );
    if($product->is_on_sale()){
        if($product->is_type( 'variable' ))
        {
            $regular_price = $product->get_variation_regular_price( 'min' );
            $sale_price = $product->get_variation_sale_price( 'min' );
        }
        else
        {
            $regular_price = $product->get_regular_price();
            $sale_price = $product->get_sale_price();
        }

        $insale_price = (int)$regular_price - (int)$sale_price;
        $discount_price = round(($insale_price/$regular_price)*100);
        return $discount_price;
    }
}

remove_action( 'woocommerce_single_variation', 'woocommerce_single_variation', 10);


add_action('woocommerce_before_variations_form', 'hami_before_variations_form');
add_action('woocommerce_after_variations_table', 'hami_after_variations_table');
function hami_before_variations_form() {
    echo '<div class="show-rate">';
    woocommerce_template_single_rating();
}
function hami_after_variations_table() {
    echo '</div>';
}
add_filter( 'woocommerce_product_description_heading', '__return_null' );
add_filter( 'woocommerce_product_additional_information_heading', '__return_null' );





add_filter( 'woocommerce_product_tabs', 'woocommerce_product_cross_sell_tab');
function woocommerce_product_cross_sell_tab( $tabs ) {
    $cross_id = get_post_meta(get_the_ID() , '_crosssell_ids' , true);
    if ($cross_id) {
        $tabs['cross_sell_tab'] = array(
            'title' => __( 'محصولات مکمل', 'woocommerce' ), // TAB TITLE
            'priority' => 20, // TAB SORTING (DESC 10, ADD INFO 20, REVIEWS 30)
            'callback' => 'woocommerce_product_cross_sell_tab_content', // TAB CONTENT CALLBACK
        );
    }

    return $tabs;
}
function woocommerce_product_cross_sell_tab_content() {
    $cross_id = get_post_meta(get_the_ID() , '_crosssell_ids' , true);
    $cross_sell = new WP_Query(array(
        'post_type' => 'product',
        'posts_per_page' => 6,
        'no_found_rows' => true,
        'post__in' => $cross_id,
    ));

    ?><div class="hami-cross-sell"> <?php
    if ($cross_sell->have_posts()) {
        while ($cross_sell->have_posts()) : $cross_sell->the_post(); ?>

            <div class="cross-item">
                <figure>
                    <a href="<?php the_permalink(); ?>" target="_blank">
                        <?php
                        if (has_post_thumbnail()) {
                            the_post_thumbnail('cross_img');
                        }
                        else {
                            ?><img src="<?php echo get_template_directory_uri() . '/img/0.jpg'; ?>"><?php
                        }
                        ?>
                    </a>
                </figure>
                <h2>
                    <a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a>
                </h2>
                <div class="down">
                    <?php
                    global $product;
                    if ($product->is_in_stock() && $product->get_price_html()) { ?>
                        <div class="addtocart_button">
                            <?php
                            echo sprintf('<a href="%s" data-quantity="1" class="%s" %s><i class="fa-solid fa-circle-plus"></i></a>',
                                esc_url($product->add_to_cart_url()),
                                esc_attr(implode(' ', array_filter(array(
                                    'button', 'product_type_' . $product->get_type(),
                                    $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
                                    $product->supports('ajax_add_to_cart') ? 'ajax_add_to_cart' : '',
                                )))),
                                wc_implode_html_attributes(array(
                                    'data-product_id' => $product->get_id(),
                                    'data-product_sku' => $product->get_sku(),
                                    'aria-label' => $product->add_to_cart_description(),
                                    'rel' => 'nofollow',
                                )),
                                esc_html($product->add_to_cart_text())
                            );
                            ?>
                        </div>
                        <div class="price">
                            <?php echo $product->get_price_html(); ?>
                        </div>
                    <?php }
                    elseif (!$product->is_in_stock()) {
                        echo "<div class='not_stock'><i class='fa-solid fa-multiply'></i> موجود نیست !</div>";
                    }
                    else {
                        echo "<div class='contact-us-price'>تماس بگیرید</div>";
                    }
                    ?>
                </div>
            </div>

    <?php
        endwhile;
    }
    wp_reset_postdata();
    ?></div><?php
}

remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20);



add_filter( 'woocommerce_product_data_tabs', 'wk_product_edit_tab', 10, 1 );
function wk_product_edit_tab( $default_tabs ) {
    $tabs = array(
        'wk_custom_tab' => array(
            'label'       => 'فروش ویژه',
            'target'      => 'wk_custom_tab', // ID of tab field
            'priority'    => 60,
            'class'       => array(),
        ),
    );
    $default_tabs = array_merge( $default_tabs, $tabs );
    return $default_tabs;
}



add_action( 'woocommerce_product_data_panels', 'wk_product_tab_field' );
function wk_product_tab_field() {
    global $post;
    ?>
    <div id="wk_custom_tab" class="panel woocommerce_options_panel">
        <?php
        woocommerce_wp_checkbox(
            array(
                'id'            => 'status_timer_offer',
                'wrapper_class' => '',
                'label'         => 'فروش ویژه..؟',
                'description'   => 'فعال',
                'deafault'      => '0',
            )
        );
        $start_date = get_post_meta($post->ID,'event_start_date',true);
        $end_date = get_post_meta($post->ID,'event_end_date',true);
        ?>
        <p class="form-field">
            <label for="datepicker1">تاریخ شروع</label>
            <input type="date" value="<?php echo $start_date; ?>" name="event_start_date" id="datepicker1">
        </p>
        <p class="form-field">
            <label for="datepicker2">تاریخ پایان</label>
            <input type="date" value="<?php echo $end_date; ?>" name="event_end_date" id="datepicker2">
        </p>
    </div>
    <?php
}


add_action( 'save_post_product', 'wk_save_custom_tab_data', 10, 3 );
function wk_save_custom_tab_data() {
    global $post;

    update_post_meta( $post->ID, 'status_timer_offer', esc_attr( $_POST['status_timer_offer'] ) );

    if ( isset( $_POST['event_start_date'] ) ) {
        update_post_meta( $post->ID, 'event_start_date', esc_attr( $_POST['event_start_date'] ) );
    }
    if ( isset( $_POST['event_end_date'] ) ) {
        update_post_meta( $post->ID, 'event_end_date', esc_attr( $_POST['event_end_date'] ) );
    }
}




// اضافه کردن تاکسونومی برند برای محصولات
add_action( 'init', 'create_brands_for_product');
function create_brands_for_product() {
    $labels = array(
        'name'              => _x( 'برندها', 'برندها' ),
        'singular_name'     => _x( 'برندها', 'برندها' ),
        'search_items'      => __( 'جستجویه برند' ),
        'all_items'         => __( 'تمام برندها' ),
        'parent_item'       => __( 'زیر برند' ),
        'parent_item_colon' => __( 'Parent Genre:' ),
        'edit_item'         => __( 'ویرایش برند' ),
        'update_item'       => __( 'بروزرسانی برند' ),
        'add_new_item'      => __( 'افزودن برند جدید' ),
        'new_item_name'     => __( 'نام جدید برند' ),
        'menu_name'         => __( 'برندها' ),
    );

    $br = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
    );

    register_taxonomy( 'product_brand', 'product' , $br );
}


remove_action( 'woocommerce_before_shop_loop', 'woocommerce_output_all_notices', 10);
add_action( 'woocommerce_before_main_content', 'woocommerce_output_all_notices', 10);

// remove cross sell from cart page
remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display');



add_action('woocommerce_before_account_navigation', 'hami_first_myaccount');
add_action('woocommerce_account_content', 'hami_end_myaccount');
function hami_first_myaccount() {
    echo '<div class="hero-myaccount">';
}
function hami_end_myaccount() {
    echo '</div>';
}






// add the ajax fetch js
add_action( 'wp_footer', 'fetch_ajax' );
function fetch_ajax() {
    ?>
    <script type="text/javascript">
        function fetch(){
            jQuery('.loader-ajax-search').addClass('show');
            jQuery('.content-ajax-search').addClass('show');
            jQuery.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'post',
                data: { action: 'data_fetch', keyword: jQuery('#keyword').val() },
                success: function(data) {
                    jQuery('#datafetch').html( data );
                }
            });
        }
    </script>
    <?php
}
// the ajax function
add_action('wp_ajax_data_fetch' , 'data_fetch');
add_action('wp_ajax_nopriv_data_fetch','data_fetch');
function data_fetch(){
    $the_query = new WP_Query( array( 'posts_per_page' => 5, 's' => esc_attr( $_POST['keyword'] ), 'post_type' => array('product') ) );
    if( $the_query->have_posts() ) :?>
        <ul>
            <?php while( $the_query->have_posts() ): $the_query->the_post(); ?>
                <li>
                    <a href="<?php the_permalink(); ?>">
                        <?php
                        echo (has_post_thumbnail() ? get_the_post_thumbnail(get_the_id(), array(200, 200), array('class' => 'main-img')) : wc_placeholder_img('woocommerce_thumbnail'));
                        ?>
                        <div>
                            <h3><?php the_title();?></h3>
                            <?php global $product; echo $product->get_price_html(); ?>
                        </div>
                    </a>

                </li>
            <?php endwhile; ?>
        </ul>
        <?php wp_reset_postdata();
    else: ?>
        <div class="not-fount-search">
            <img src="<?php echo get_template_directory_uri(); ?>/img/not-found-serach.png">
            <p>متاسفانه چیزی پیدا نکردم</p>
        </div>
    <?php endif;

    die();
}





require_once get_theme_file_path() .'/include/codestar-framework-2.3.1/codestar-framework.php';

require_once 'include/hami-options.php';
require_once 'include/review-fields.php';
require_once 'include/breadcrumb.php';
require_once 'include/custom-style.php';
require_once 'elementor/hami-elementor.php';