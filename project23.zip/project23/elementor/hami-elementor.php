<?php

add_action( 'elementor/widgets/register', 'register_new_widgets' );
function register_new_widgets( $widgets_manager ) {

    require_once( __DIR__ . '/widgets/main-slider.php' );
    $widgets_manager->register( new \hami_main_slider() );


    require_once( __DIR__ . '/widgets/product.php' );
    $widgets_manager->register( new \hami_product() );

    require_once( __DIR__ . '/widgets/amazing.php' );
    $widgets_manager->register( new \hami_product_amazing() );

    require_once( __DIR__ . '/widgets/special.php' );
    $widgets_manager->register( new \hami_product_special() );


    require_once( __DIR__ . '/widgets/best-sell.php' );
    $widgets_manager->register( new \hami_best_sell() );


    require_once( __DIR__ . '/widgets/article.php' );
    $widgets_manager->register( new \hami_article() );


    require_once( __DIR__ . '/widgets/instagram.php' );
    $widgets_manager->register( new \hami_instagram() );


    require_once( __DIR__ . '/widgets/brand.php' );
    $widgets_manager->register( new \hami_brand() );


    require_once( __DIR__ . '/widgets/service.php' );
    $widgets_manager->register( new \hami_service() );


    require_once( __DIR__ . '/widgets/story.php' );
    $widgets_manager->register( new \hami_story() );

}


add_action( 'elementor/elements/categories_registered', 'add_elementor_widget_categories' );
function add_elementor_widget_categories( $elements_manager ) {

    $elements_manager->add_category(
        'hami_widgets',
        [
            'title' => esc_html__( 'اختصاصی حامی', 'textdomain' ),
            'icon' => 'fa fa-plug',
        ]
    );

}
