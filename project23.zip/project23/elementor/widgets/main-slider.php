<?php

class hami_main_slider extends \Elementor\Widget_Base {

    public function get_name() {
        return 'main_slider';
    }

    public function get_title() {
        return 'اسلایدر اصلی حامی';
    }

    public function get_icon() {
        return 'eicon-slides';
    }

    public function get_categories() {
        return [ 'hami_widgets' ];
    }

    public function get_keywords() {
        return [ 'slide', 'slider' , 'slideshow' ];
    }

    /*public function get_custom_help_url() {}

    protected function get_upsale_data() {}*/

    /*public function get_script_depends() {}

    public function get_style_depends() {
        return [ 'test' ];
    }*/

    /*protected function is_dynamic_content() {}*/

    protected function register_controls() {

        $this->start_controls_section(
            'slider_section',
            [
                'label' => 'تنظیمات اسلایدر',
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );


        $this->add_control(
            'main_slider_list',
            [
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'image_main_slider',
                        'label' => 'انتخاب تصویر',
                        'type' => \Elementor\Controls_Manager::MEDIA,
                        'default' => [
                            'url' => \Elementor\Utils::get_placeholder_image_src(),
                        ],
                    ],
                    [
                        'name' => 'url_main_slider',
                        'label' => 'لینک اسلاید',
                        'type' => \Elementor\Controls_Manager::URL,
                    ],

                ],
                'default' => [
                    [
                        'image_main_slider' => esc_html__( 'Title #1', 'textdomain' ),
                        'url_main_slider' => esc_html__( 'Item content. Click the edit button to change this text.', 'textdomain' ),
                    ],
                ],
                'title_field' => 'اسلایدر',
            ]
        );


        $this->end_controls_section();



        $this->start_controls_section(
            'slider_style_section',
            [
                'label' => 'تنظیمات استایل',
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'show_nav_slider',
            [
                'label' => 'نمایش پیکان ها',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'نمایش', 'textdomain' ),
                'label_off' => esc_html__( 'مخفی', 'textdomain' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'show_bullet_slider',
            [
                'label' => 'نقطه های زیر اسلایدر',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'نمایش', 'textdomain' ),
                'label_off' => esc_html__( 'مخفی', 'textdomain' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'autoplay',
            [
                'label' => 'حرکت خودکار',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'فعال', 'textdomain' ),
                'label_off' => esc_html__( 'غیرفعال', 'textdomain' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'radius',
            [
                'label' => 'گوشه های گرد',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'فعال', 'textdomain' ),
                'label_off' => esc_html__( 'غیرفعال', 'textdomain' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $sliders = $settings['main_slider_list'];
        ?>
        <section class="main-slider">
            <div class="owl-carousel owl-theme m-slider">
                <?php
                foreach ($sliders as $item) { ?>
                    <div class="item"><a href="<?php echo $item['url_main_slider']['url']; ?>"><img src="<?php echo $item['image_main_slider']['url']; ?>"> </a> </div>
                <?php } ?>
            </div>
        </section>

        <script>
            $(function (){
                $('.m-slider').owlCarousel({
                    loop:true,
                    autoplay:<?php if ($settings['autoplay']) {echo "true";} else {echo "false";} ?>,
                    margin:0,
                    nav: <?php if ($settings['show_nav_slider']) {echo "true";} else {echo "false";} ?>,
                    rtl: true,
                    dots:<?php if ($settings['show_bullet_slider']) {echo "true";} else {echo "false";} ?>,
                    navText : "",
                    responsive:{
                        0:{
                            items:1
                        },
                        600:{
                            items:1
                        },
                        1000:{
                            items:1
                        }
                    }
                })
            })
        </script>

        <?php
        if (!$settings['radius']) { ?>
            <style>
                .main-slider .owl-stage-outer {
                    border-radius: 0px;
                }
            </style>
        <?php } ?>
        <?php
    }

}
