<?php

class hami_product extends \Elementor\Widget_Base {

    public function get_name() {
        return 'hami_prodcut';
    }

    public function get_title() {
        return 'نمایش محصولات';
    }

    public function get_icon() {
        return 'eicon-products';
    }

    public function get_categories() {
        return [ 'hami_widgets' ];
    }

    public function get_keywords() {
        return [ 'product'];
    }

    function get_product_cats(){
        $cat_list = [];
        $product_cats = get_terms( array(
            'taxonomy'   => 'product_cat',
            'hide_empty' => true,
        ) );
        foreach ($product_cats as $cat) {
            $cat_list [$cat->term_id] = $cat->name;
        }
        return $cat_list;
    }
    function get_product_tags(){
        $tag_list = [];
        $product_tags = get_terms('product_tag');
        foreach ($product_tags as $tag) {
            $tag_list [$tag->term_id] = $tag->name;
        }
        return $tag_list;
    }
    function get_product_brands(){
        $brand_list = [];
        $product_brands = get_terms('product_brand');
        foreach ($product_brands as $brand) {
            $brand_list [$brand->term_id] = $brand->name;
        }
        return $brand_list;
    }
    protected function register_controls() {

        $this->start_controls_section(
            'product_section',
            [
                'label' => 'المان محصولات',
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => 'عنوان',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'جدیدترین محصولات حامی',
                'label_block' => true,
            ]
        );
        $this->add_control(
            'link',
            [
                'label' => 'لینک',
                'type' => \Elementor\Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'label_block' => true,
            ]
        );

        $this->add_control(
            'product_style',
            [
                'label' => 'سبک نمایش',
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'style1' => esc_html__( 'سبک 1', 'textdomain' ),
                    'style2' => esc_html__( 'سبک 2', 'textdomain' ),
                ],
                'default' => 'style1',
            ]
        );

        $this->add_control(
            'product_filter',
            [
                'label' => 'فیلتر محصولات',
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'all' => esc_html__( 'همه محصولات', 'textdomain' ),
                    'category' => esc_html__( 'بر اساس دسته بندی', 'textdomain' ),
                    'tag' => esc_html__( 'بر اساس برچسب', 'textdomain' ),
                    'brand' => esc_html__( 'بر اساس برند', 'textdomain' ),
                ],
                'default' => 'all',
            ]
        );

        $this->add_control(
            'cat',
            [
                'label' => 'دسته بندی',
                'type' => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'multiple' => true,
                'options' => $this->get_product_cats(),
                'condition' => [
                    'product_filter' => 'category',
                ],
            ]
        );

        $this->add_control(
            'tag',
            [
                'label' => 'برچسب',
                'type' => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'multiple' => true,
                'options' => $this->get_product_tags(),
                'condition' => [
                    'product_filter' => 'tag',
                ],
            ]
        );
        $this->add_control(
            'brand',
            [
                'label' => 'برند',
                'type' => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'multiple' => true,
                'options' => $this->get_product_brands(),
                'condition' => [
                    'product_filter' => 'brand',
                ],
            ]
        );

        $this->add_control(
            'product_number',
            [
                'label' => 'تعداد محصولات',
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 20,
                'step' => 1,
                'default' => 6,
            ]
        );
        $this->add_control(
            'item_slide',
            [
                'label' => 'تعداد آیتم های اسلایدر',
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 4,
                'max' => 6,
                'step' => 1,
                'default' => 5,
            ]
        );
        $this->add_control(
            'show_nav',
            [
                'label' => 'نمایش نقطه ها',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'نمایش', 'textdomain' ),
                'label_off' => esc_html__( 'مخفی', 'textdomain' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'attributes',
            [
                'label' => 'نمایش ویژگی ها',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'نمایش', 'textdomain' ),
                'label_off' => esc_html__( 'مخفی', 'textdomain' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'stock',
            [
                'label' => 'حذف محصولات ناموجود',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'فعال', 'textdomain' ),
                'label_off' => esc_html__( 'غیرفعال', 'textdomain' ),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        ?>
        <section class="hero-product">
            <div class="container">
                <?php if ($settings['title']) { ?>
                <header class="title-pro">
                    <?php
                        $target = $settings['link']['is_external'] ? 'target="_blank"' : '';
                        $nofollow = $settings['link']['nofollow'] ? 'rel="nofollow"' : '';
                    ?>
                    <h4><a <?php echo $target,$nofollow; ?> href="<?php echo $settings['link']['url']; ?>"><?php echo $settings['title']; ?></a> </h4>
                </header>
                <?php } ?>

                <div class="owl-carousel owl-theme product-slider">

                    <?php

                    $product_args = array(
                        'post_type' => 'product',
                        'posts_per_page' => $settings['product_number'],
                        'no_found_rows' => true,

                    );

                    if ($settings['product_filter'] == 'category') {
                        $add_query = array(
                            'relation' => 'OR',
                            array(
                                'taxonomy' => 'product_cat',
                                'field' => 'term_id',
                                'terms' => $settings['cat'],
                            ),
                        );
                        $product_args['tax_query'] = $add_query;
                    }
                    elseif ($settings['product_filter'] == 'tag') {
                        $add_query = array(
                            'relation' => 'OR',
                            array(
                                'taxonomy' => 'product_tag',
                                'field' => 'term_id',
                                'terms' => $settings['tag'],
                            ),
                        );
                        $product_args['tax_query'] = $add_query;
                    }
                    elseif ($settings['product_filter'] == 'brand') {
                        $add_query = array(
                            'relation' => 'OR',
                            array(
                                'taxonomy' => 'product_brand',
                                'field' => 'term_id',
                                'terms' => $settings['brand'],
                            ),
                        );
                        $product_args['tax_query'] = $add_query;
                    }

                    if ($settings['stock']) {
                        $add_query = array(
                            array(
                                'key'     => '_stock_status',
                                'value'   => 'instock',
                                'compare' => '=',
                            ),
                        );
                        $product_args['meta_query'] = $add_query;
                    }

                    global $product;
                    $new_product = new WP_Query($product_args);

                    if ($new_product->have_posts()) {
                        while ($new_product->have_posts()) : $new_product->the_post(); ?>
                            <div class="item product-item">
                                <div class="color-dis">
                                    <?php
                                    global $product;
                                    if ($settings['attributes']) {
                                    $attr_taxonomy = wc_get_attribute_taxonomies();
                                    foreach ($attr_taxonomy as $item) {
                                        $attr_name = $item->attribute_name;
                                        $terms = get_the_terms($product->ID, 'pa_' . $attr_name);
                                        if (is_array($terms)) {
                                            ?>
                                            <div class="color">
                                                <ul>
                                                    <?php
                                                    foreach ($terms as $term) {
                                                        $tooltip = $term->name;
                                                        $colors = get_term_meta($term->term_id, 'product_attribute_color', 1);
                                                        ?>
                                                        <li>
                                                            <?php if ($colors) { ?>
                                                                <span style="background: <?php echo $colors; ?>"><b><?php echo $tooltip; ?></b></span>
                                                            <?php } else {
                                                                ?><small><?php echo $tooltip; ?></small><?php
                                                            }?>
                                                        </li>
                                                        <?php
                                                    }
                                                    ?>
                                                </ul>
                                            </div>
                                            <?php
                                        }
                                    }
                                    }
                                    ?>



                                    <?php if ($product->is_on_sale()) : ?>
                                        <div class="discount">
                                            <?php echo hami_wooocmmerce_discount(get_the_ID()); ?>%
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <figure>
                                    <a href="<?php the_permalink(); ?>" target="_blank">
                                        <?php
                                        if (has_post_thumbnail()) {
                                            the_post_thumbnail('product');
                                        }
                                        else {
                                            ?><img src="<?php echo get_template_directory_uri() . '/img/0.jpg'; ?>"><?php
                                        }
                                        ?>
                                    </a>
                                </figure>
                                <h2>
                                    <a href="<?php the_permalink(); ?>" target="_blank"><?php the_title(); ?></a>
                                </h2>

                                <?php if ($settings['product_style'] == 'style1') { ?>
                                <div class="down">
                                    <?php if ($product->is_in_stock() && $product->get_price_html()) { ?>
                                        <div class="addtocart_button">
                                            <?php
                                            echo sprintf('<a href="%s" data-quantity="1" class="%s" %s><i class="fa-solid fa-circle-plus"></i></a>',
                                                esc_url($product->add_to_cart_url()),
                                                esc_attr(implode(' ', array_filter(array(
                                                    'button', 'product_type_' . $product->get_type(),
                                                    $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
                                                    $product->supports('ajax_add_to_cart') ? 'ajax_add_to_cart' : '',
                                                )))),
                                                wc_implode_html_attributes(array(
                                                    'data-product_id' => $product->get_id(),
                                                    'data-product_sku' => $product->get_sku(),
                                                    'aria-label' => $product->add_to_cart_description(),
                                                    'rel' => 'nofollow',
                                                )),
                                                esc_html($product->add_to_cart_text())
                                            );
                                            ?>
                                        </div>
                                        <div class="price">
                                            <?php echo $product->get_price_html(); ?>
                                        </div>
                                    <?php }
                                    elseif (!$product->is_in_stock()) {
                                        echo "<div class='not_stock'><i class='fa-solid fa-multiply'></i> موجود نیست !</div>";
                                    }
                                    else {
                                        echo "<div class='contact-us-price'>تماس بگیرید</div>";
                                    }
                                    ?>
                                </div>
                                <?php } else { ?>
                                    <div class="down down-two">
                                        <?php
                                        if ($product->is_in_stock()) : ?>
                                            <?php if ($product->get_price_html()) : ?>
                                                <div class="price"><?php echo $product->get_price_html(); ?></div>
                                            <?php else : ?>
                                                <div style="font-weight: 600;">تماس بگیرید</div>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <div class="not_stock"><i class="fa-solid fa-multiply"></i>موجود نیست !</div>
                                        <?php endif;?>

                                        <div class="wish-add">
                                            <div class="add-to-cart">
                                                <?php
                                                echo sprintf('<a href="%s" data-quantity="1" class="%s" %s> %s</a>',
                                                    esc_url($product->add_to_cart_url()),
                                                    esc_attr(implode(' ', array_filter(array(
                                                        'button', 'product_type_' . $product->get_type(),
                                                        $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
                                                        $product->supports('ajax_add_to_cart') ? 'ajax_add_to_cart' : '',
                                                    )))),
                                                    wc_implode_html_attributes(array(
                                                        'data-product_id' => $product->get_id(),
                                                        'data-product_sku' => $product->get_sku(),
                                                        'aria-label' => $product->add_to_cart_description(),
                                                        'rel' => 'nofollow',
                                                    )),
                                                    esc_html($product->add_to_cart_text())
                                                );
                                                ?>
                                            </div>
                                            <div class="wishlist-button">
                                                <?php
                                                $id = $product->id;
                                                echo do_shortcode("[woosw id=$id]") ?>
                                            </div>
                                        </div>

                                    </div>
                                <?php } ?>
                            </div>
                        <?php
                        endwhile;
                    }
                    wp_reset_postdata();
                    ?>

                </div>
            </div>
        </section>
        <script>
            $(function (){
                $('.product-slider').owlCarousel({
                    loop:false,
                    margin:0,
                    nav:true,
                    rtl: true,
                    dots: <?php if ($settings['show_nav']) {echo "true";} else {echo "false";} ?>,
                    navText : "",
                    responsive:{
                        0:{
                            items:1
                        },
                        576:{
                            items:2
                        },
                        768:{
                            items:3
                        },
                        992:{
                            items:4
                        },
                        1200:{
                            items:<?php echo $settings['item_slide']; ?>
                        }
                    }
                })
            })
        </script>
        <?php
    }

}
