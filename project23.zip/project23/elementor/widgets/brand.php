<?php

class hami_brand extends \Elementor\Widget_Base {

    public function get_name() {
        return 'hami_brand';
    }

    public function get_title() {
        return 'برندها';
    }

    public function get_icon() {
        return 'eicon-logo';
    }

    public function get_categories() {
        return [ 'hami_widgets' ];
    }

    public function get_keywords() {
        return [ 'brand'];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'brand_section',
            [
                'label' => 'تنظیمات',
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => 'عنوان',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => ' محبوب ترین برند ها ',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'item_slide',
            [
                'label' => 'تعداد آیتم های اسلایدر',
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 3,
                'max' => 9,
                'step' => 1,
                'default' => 6,
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => 'حرکت خودکار',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'فعال', 'textdomain' ),
                'label_off' => esc_html__( 'غیرفعال', 'textdomain' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'loop',
            [
                'label' => 'حلقه بی نهایت',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'فعال', 'textdomain' ),
                'label_off' => esc_html__( 'غیرفعال', 'textdomain' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'empty',
            [
                'label' => 'خالی ها پنهاد شود',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'فعال', 'textdomain' ),
                'label_off' => esc_html__( 'غیرفعال', 'textdomain' ),
                'return_value' => 'yes',
                'default' => '',
            ]
        );


        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="hero-product">
            <div class="container">
                <?php if ($settings['title']) { ?>
                <div class="title-brand">
                    <h4><?php echo $settings['title']; ?></h4>
                </div>
                <?php } ?>
                <div class="box-brand">
                    <div class="inner-brand">
                        <div class="owl-carousel owl-theme brand-slider">

                            <?php
                            $empty = $settings['empty'] ? 1 : 0;
                            $brands = get_terms( array(
                                'taxonomy'   => 'product_brand',
                                'hide_empty' => $empty,
                            ) );
                            //var_dump($brands);
                            foreach ($brands as $brand) {
                                ?>
                                <div class="item brand-item">
                                    <a href="<?php echo get_term_link($brand->term_id); ?>" target="_blank">
                                        <figure>
                                            <?php
                                            $attach_id = get_term_meta($brand->term_id, 'brand_thumbnail', 1);
                                            echo wp_get_attachment_image($attach_id , 'full');
                                            ?>
                                        </figure>
                                    </a>
                                </div>
                            <?php } ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>

        <script>
            $(function () {
                $('.brand-slider').owlCarousel({
                    autoplay : <?php if ($settings['autoplay']) {echo "true";} else {echo "false";} ?>,
                    loop:<?php if ($settings['loop']) {echo "true";} else {echo "false";} ?>,
                    margin:0,
                    nav:true,
                    rtl: true,
                    navText : "",
                    dots: false,
                    responsive:{
                        0:{
                            items:1
                        },
                        576:{
                            items:3
                        },
                        768:{
                            items:4
                        },
                        992:{
                            items:5
                        },
                        1100:{
                            items:<?php echo $settings['item_slide']; ?>
                        }
                    }
                })
            })
        </script>
        <?php
    }

}
