<?php

class hami_service extends \Elementor\Widget_Base {

    public function get_name() {
        return 'hami_service';
    }

    public function get_title() {
        return 'آیتم های تجاری';
    }

    public function get_icon() {
        return 'eicon-call-to-action';
    }

    public function get_categories() {
        return [ 'hami_widgets' ];
    }

    public function get_keywords() {
        return [ 'service' ];
    }


    protected function register_controls() {

        $this->start_controls_section(
            'service_section',
            [
                'label' => 'تنظیمات ',
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );


        $this->add_control(
            'service_list',
            [
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'image_service',
                        'label' => 'انتخاب تصویر',
                        'type' => \Elementor\Controls_Manager::MEDIA,
                        'default' => [
                            'url' => get_template_directory_uri().'/img/service/s1.png',
                        ],
                    ],
                    [
                        'name' => 'title',
                        'label' => 'عنوان',
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => 'پرداخت امن و مطمئن',
                    ],
                    [
                        'name' => 'subtitle',
                        'label' => 'زیر عنوان',
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => 'درگاه پرداخت امن و دارای مجوز اینماد',
                    ],

                ],
                'default' => [
                    [
                        'image_service' => esc_html__( 'Title #1', 'textdomain' ),
                        'title' => 'پرداخت امن و مطمئن',
                        'subtitle' => 'درگاه پرداخت امن و دارای مجوز اینماد',
                    ],
                    [
                        'image_service' => esc_html__( 'Title #1', 'textdomain' ),
                        'title' => 'پرداخت امن و مطمئن',
                        'subtitle' => 'درگاه پرداخت امن و دارای مجوز اینماد',
                    ],
                ],
                'title_field' => 'آیتم',
            ]
        );


        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $services = $settings['service_list'];
        ?>

        <section class="hero-product">
            <div class="container">
                <div class="hami-service">
                    <?php foreach ($services as $service) { ?>
                    <div class="service-item">
                        <img src="<?php echo $service['image_service']['url']; ?>">
                        <b><?php echo $service['title']; ?></b>
                        <span><?php echo $service['subtitle']; ?></span>
                    </div>
                    <?php } ?>

                </div>
            </div>
        </section>

        <?php
    }

}
