<?php

class hami_story extends \Elementor\Widget_Base {

    public function get_name() {
        return 'hami_story';
    }

    public function get_title() {
        return 'استوری';
    }

    public function get_icon() {
        return 'eicon-counter-circle';
    }

    public function get_categories() {
        return [ 'hami_widgets' ];
    }

    public function get_keywords() {
        return [ 'story' ];
    }


    protected function register_controls() {

        $this->start_controls_section(
            'story_section',
            [
                'label' => 'تنظیمات ',
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );


        $this->add_control(
            'story_list',
            [
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'title',
                        'label' => 'عنوان',
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => 'حامی',
                    ],
                    [
                        'name' => 'image_thumbnail',
                        'label' => 'تصویر کوچک پیشنمایش استوری',
                        'type' => \Elementor\Controls_Manager::MEDIA,
                        'default' => [
                            'url' => get_template_directory_uri().'/img/1-3.jpg',
                        ],
                    ],
                    [
                        'name' => 'time',
                        'label' => 'مدت زمان هر استوری (ثانیه)',
                        'type' => \Elementor\Controls_Manager::NUMBER,
                        'min' => 1,
                        'max' => 600,
                        'step' => 1,
                        'default' => 5,
                    ],
                    [
                        'name' => 'hr',
                        'type' => \Elementor\Controls_Manager::DIVIDER,
                    ],
                    [
                        'name' => 'type',
                        'label' => 'محتوای استوری',
                        'type' => \Elementor\Controls_Manager::CHOOSE,
                        'options' => [
                            'photo' => [
                                'title' => 'عکس',
                                'icon' => 'eicon-image-bold',
                            ],
                            'video' => [
                                'title' => 'ویدیو',
                                'icon' => 'eicon-video-camera',
                            ],
                        ],
                        'default' => 'photo',
                        'toggle' => false,
                    ],
                    [
                        'name' => 'gallery',
                        'label' => 'عکس های استوری',
                        'type' => \Elementor\Controls_Manager::GALLERY,
                        'show_label' => false,
                        'default' => [],
                        'condition' => [
                                'type' => 'photo',
                        ],
                    ],
                    [
                        'name' => 'link_video',
                        'label' => 'لینک ویدیو',
                        'type' => \Elementor\Controls_Manager::URL,
                        'label_block' => true,
                        'options' => [ 'url', 'is_external', 'nofollow' ],
                        'condition' => [
                            'type' => 'video',
                        ],
                    ],
                    [
                        'name' => 'hr',
                        'type' => \Elementor\Controls_Manager::DIVIDER,
                    ],
                    [
                        'name' => 'title_btn',
                        'label' => 'متن دکمه لینک استوری',
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => 'کلیک کنید',
                    ],
                    [
                        'name' => 'link_story',
                        'label' => 'لینک استوری',
                        'type' => \Elementor\Controls_Manager::URL,
                        'label_block' => true,
                        'options' => [ 'url', 'is_external', 'nofollow' ],
                        'default' => [
                            'url' => '#',
                            'is_external' => true,
                            'nofollow' => false,
                            // 'custom_attributes' => '',
                        ],
                    ],

                ],
                'default' => [
                    [
                        'title' => 'حامی',
                        'image_thumbnail' => '',
                        'time' => 5,
                        'type' => 'photo',
                        'gallery' => '',
                        'link_video' => '',
                        'title_btn' => 'کلیک کنید',
                        'link_story' => '',
                    ],
                ],
                'title_field' => 'استوری',
            ]
        );


        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $stories = $settings['story_list'];
        ?>

        <div id="stories" class="hami-story"></div>

        <script src="<?php echo get_template_directory_uri() . '/js/zuck.js'; ?>"></script>
        <script src="<?php echo get_template_directory_uri() . '/js/script.js'; ?>"></script>

        <script>
            var currentSkin = getCurrentSkin();
            var stories = window.Zuck(document.querySelector('#stories'), {
                backNative: true,
                previousTap: true,
                skin: currentSkin['name'],
                autoFullScreen: currentSkin['params']['autoFullScreen'],
                avatars: currentSkin['params']['avatars'],
                paginationArrows: currentSkin['params']['paginationArrows'],
                list: currentSkin['params']['list'],
                cubeEffect: currentSkin['params']['cubeEffect'],
                localStorage: true,
                stories: [
                    <?php foreach ($stories as $story) : ?>
                    {
                        id: '<?php echo $story['_id']; ?>',
                        photo:
                            '<?php echo $story['image_thumbnail']['url']; ?>',
                        name: '<?php echo $story['title']; ?>',
                        time: timestamp(),
                        items: [
                            <?php if ($story['type']=='photo' && is_array($story['gallery'])) {
                            foreach ($story['gallery'] as $gallery) : ?>
                            {
                                id: '<?php echo $story['_id']."-".$gallery['id']; ?>',
                                type: 'photo',
                                length: <?php echo $story['time']; ?>,
                                src: '<?php echo $gallery['url']; ?>',
                                preview: '<?php echo $gallery['url']; ?>',
                                link: '<?php echo $story['link_story']['url']; ?>',
                                linkText: "<?php echo $story['title_btn']; ?>",
                                time: timestamp()
                            },
                            <?php endforeach; ?>

                            <?php } elseif ($story['type']=='video') { ?>
                            {
                                id: '<?php echo $story['_id'].rand(); ?>',
                                type: 'video',
                                length: 0,
                                src: '<?php echo $story['link_video']['url']; ?>',
                                preview: '<?php echo $story['image_thumbnail']['url']; ?>',
                                link: '<?php echo $story['link_story']['url']; ?>',
                                linkText: "<?php echo $story['title_btn']; ?>",
                                time: timestamp()
                            },
                            <?php } ?>
                        ]
                    },
                    <?php endforeach; ?>
                ]
            });
        </script>

        <?php
    }

}
