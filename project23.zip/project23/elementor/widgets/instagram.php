<?php

class hami_instagram extends \Elementor\Widget_Base {

    public function get_name() {
        return 'hami_instagram';
    }

    public function get_title() {
        return 'پست های اینستاگرام';
    }

    public function get_icon() {
        return 'eicon-instagram-post';
    }

    public function get_categories() {
        return [ 'hami_widgets' ];
    }

    public function get_keywords() {
        return [ 'instagram'];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'insta_section',
            [
                'label' => 'تنظیمات',
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'insta_number',
            [
                'label' => 'تعداد پست',
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 30,
                'step' => 1,
                'default' => 6,
            ]
        );
        $this->add_control(
            'item_slide',
            [
                'label' => 'تعداد آیتم های اسلایدر',
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 4,
                'max' => 7,
                'step' => 1,
                'default' => 6,
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => 'حرکت خودکار',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'فعال', 'textdomain' ),
                'label_off' => esc_html__( 'غیرفعال', 'textdomain' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'loop',
            [
                'label' => 'حلقه بی نهایت',
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'فعال', 'textdomain' ),
                'label_off' => esc_html__( 'غیرفعال', 'textdomain' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
        $this->add_control(
            'image',
            [
                'label' => 'تصویر اینستاگرام',
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => get_template_directory_uri().'/img/insta.png',
                ],
            ]
        );
        $this->add_control(
            'link',
            [
                'label' => 'آدرس پیج',
                'type' => \Elementor\Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'label_block' => true,
                'default' => [
                    'is_external' => true,
                    'nofollow' => true,
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'bg',
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .box-insta',
            ]
        );

        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="hero-product">
            <div class="container">
                <div class="box-insta">
                    <div class="first-item">
                        <?php
                        $target = $settings['link']['is_external'] ? 'target="_blank"' : '';
                        $nofollow = $settings['link']['nofollow'] ? 'rel="nofollow"' : '';
                        ?>
                        <a <?php echo $target,$nofollow; ?> href="<?php echo $settings['link']['url']; ?>" target="_blank">
                            <figure class="amazing-thumbnail">
                                <?php if ($settings['image']['url']) { ?>
                                    <img src="<?php echo $settings['image']['url']; ?>">
                                <?php } else { ?>
                                <img src="<?php echo get_template_directory_uri() . '/img/insta.png'; ?>">
                                <?php } ?>
                            </figure>
                        </a>
                    </div>
                    <div class="left-item">
                        <div class="owl-carousel owl-theme insta-slider">

                            <?php
                            $insta_post = new WP_Query(array(
                                'post_type' => 'insta',
                                'posts_per_page' => $settings['insta_number'],
                                'no_found_rows' => true,
                            ));

                            if ($insta_post->have_posts()) {
                                while ($insta_post->have_posts()) : $insta_post->the_post(); ?>
                                    <div class="item product-item">
                                        <a href="<?php the_permalink(); ?>" target="_blank">
                                            <figure>
                                                <?php
                                                if (has_post_thumbnail()) {
                                                    the_post_thumbnail();
                                                }
                                                else {
                                                    ?><img src="<?php echo get_template_directory_uri() . '/img/i-1.jpg'; ?>"><?php
                                                }
                                                ?>
                                            </figure>
                                        </a>
                                    </div>
                                <?php
                                endwhile;
                            }
                            wp_reset_postdata();
                            ?>

                        </div>
                    </div>
                </div>
            </div>
            </div>
        </section>

        <script>
            $(function () {
                $('.insta-slider').owlCarousel({
                    autoplay : <?php if ($settings['autoplay']) {echo "true";} else {echo "false";} ?>,
                    loop:<?php if ($settings['loop']) {echo "true";} else {echo "false";} ?>,
                    margin:0,
                    nav:false,
                    rtl: true,
                    navText : "",
                    dots: false,
                    responsive:{
                        0:{
                            items:1
                        },
                        576:{
                            items:3
                        },
                        768:{
                            items:4
                        },
                        992:{
                            items:<?php echo $settings['item_slide']; ?>
                        }
                    }
                })
            })
        </script>
        <?php
    }

}
