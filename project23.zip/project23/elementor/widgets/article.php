<?php

class hami_article extends \Elementor\Widget_Base {

    public function get_name() {
        return 'hami_article';
    }

    public function get_title() {
        return 'مقالات';
    }

    public function get_icon() {
        return 'eicon-post-list';
    }

    public function get_categories() {
        return [ 'hami_widgets' ];
    }

    public function get_keywords() {
        return [ 'article'];
    }

    function get_article_cats(){
        $cat_list = [];
        $article_cats = get_categories();
        foreach ($article_cats as $cat) {
            $cat_list [$cat->cat_ID] = $cat->cat_name;
        }
        return $cat_list;
    }

    protected function register_controls() {

        $this->start_controls_section(
            'article_section',
            [
                'label' => 'المان مقالات',
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => 'عنوان',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'پرفروش ترین محصولات',
                'label_block' => true,
            ]
        );
        $this->add_control(
            'link',
            [
                'label' => 'لینک',
                'type' => \Elementor\Controls_Manager::URL,
                'options' => [ 'url', 'is_external', 'nofollow' ],
                'label_block' => true,
            ]
        );

        $this->add_control(
            'article_filter',
            [
                'label' => 'فیلتر مقالات',
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'all' => esc_html__( 'همه مقالات', 'textdomain' ),
                    'category' => esc_html__( 'بر اساس دسته بندی', 'textdomain' ),
                ],
                'default' => 'all',
            ]
        );

        $this->add_control(
            'cat',
            [
                'label' => 'دسته بندی',
                'type' => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'multiple' => true,
                'options' => $this->get_article_cats(),
                'condition' => [
                    'article_filter' => 'category',
                ],
            ]
        );


        $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="hero-blog">
            <div class="container">


                <?php if ($settings['title']) { ?>
                    <header class="title-pro">
                        <?php
                        $target = $settings['link']['is_external'] ? 'target="_blank"' : '';
                        $nofollow = $settings['link']['nofollow'] ? 'rel="nofollow"' : '';
                        ?>
                        <h4><a <?php echo $target,$nofollow; ?> href="<?php echo $settings['link']['url']; ?>"><?php echo $settings['title']; ?></a> </h4>
                    </header>
                <?php } ?>

                <div class="box-blog">


                    <?php
                    $article_args = array(
                        'post_type' => 'post',
                        'posts_per_page' => 1,
                        'no_found_rows' => true,
                    );

                    if ($settings['article_filter'] == 'category') {
                        $article_args['category__in'] = $settings['cat'];
                    }

                    $big_post = new WP_Query($article_args);

                    if ($big_post->have_posts()) {
                        while ($big_post->have_posts()) : $big_post->the_post(); ?>
                            <div class="big-post">
                                <a href="<?php the_permalink(); ?>" target="_blank">
                                    <figure>
                                        <?php
                                        if (has_post_thumbnail()) {
                                            the_post_thumbnail('big-post');
                                        }
                                        else {
                                            ?><img src="<?php echo get_template_directory_uri() . '/img/0.jpg'; ?>"><?php
                                        }
                                        ?>
                                    </figure>
                                    <div class="title">
                                        <h2><?php the_title(); ?>
                                            <i class="fa-solid fa-arrow-left"></i>
                                        </h2>
                                    </div>
                                </a>
                            </div>
                        <?php
                        endwhile;
                    }
                    wp_reset_postdata();
                    ?>


                    <div class="small-post">

                        <?php
                        $article_args2 = array(
                            'post_type' => 'post',
                            'posts_per_page' => 4,
                            'no_found_rows' => true,
                            'offset' => 1,
                        );
                        if ($settings['article_filter'] == 'category') {
                            $article_args2['category__in'] = $settings['cat'];
                        }
                        $small_post = new WP_Query($article_args2);

                        if ($small_post->have_posts()) {
                            while ($small_post->have_posts()) : $small_post->the_post(); ?>
                                <div class="post-item">
                                    <a href="<?php the_permalink(); ?>" target="_blank">
                                        <figure>
                                            <?php
                                            if (has_post_thumbnail()) {
                                                the_post_thumbnail('small-post');
                                            }
                                            else {
                                                ?><img src="<?php echo get_template_directory_uri() . '/img/0.jpg'; ?>"><?php
                                            }
                                            ?>
                                        </figure>
                                        <h2><?php the_title(); ?></h2>
                                        <div class="down">
                                            <span><?php the_time('d F Y'); ?></span>
                                            <i class="fa-solid fa-arrow-left"></i>
                                        </div>
                                    </a>
                                </div>
                            <?php
                            endwhile;
                        }
                        wp_reset_postdata();
                        ?>

                    </div>

                </div>
            </div>
        </section>
        <?php
    }

}
