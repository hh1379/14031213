<?php
/**
 * The template for displaying product content in the single-product.php template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;
$options = get_option( 'options' );
/**
 * Hook: woocommerce_before_single_product.
 *
 * @hooked woocommerce_output_all_notices - 10
 */
do_action( 'woocommerce_before_single_product' );

if ( post_password_required() ) {
	echo get_the_password_form(); // WPCS: XSS ok.
	return;
}
?>
<div id="product-<?php the_ID(); ?>" <?php wc_product_class( '', $product ); ?>>
    <section class="product-intro">
        <div class="summary entry-summary">
            <header>
                <h1><?php the_title(); ?></h1>
                <span><?php the_field('english_name'); ?></span>
            </header>
            <div class="product-meta">
                <div>
                    <?php
                    $brands = get_the_terms(get_the_ID(), 'product_brand');
                    if ($brands && $options['active_brand']) :
                    ?>
                    <div class="meta-pro">
                        <i class="fa-solid fa-meteor"></i>
                        <span>برند : </span>
                        <a href="<?php echo get_term_link($brands[0]->term_id); ?>" target="_blank"><?php echo $brands[0]->name; ?></a>
                    </div>
                    <?php endif; ?>
                    <?php if ($options['active_stock']) { ?>
                    <div class="meta-pro">
                        <?php
                        $stock = $product->get_stock_status();
                        if ($stock == 'instock') { ?>
                            <i class="fa-solid fa-circle-check"></i>
                            <span>موجود در انبار</span>
                        <?php } else { ?>
                            <i class="fa-solid fa-xmark"></i>
                            <span>موجود نیست!</span>
                        <?php }
                        ?>

                    </div>
                    <?php } ?>
                </div>
                <div>
                    <?php if ($options['active_category']) { ?>
                    <div class="meta-pro">
                        <i class="fa-solid fa-qrcode"></i>
                        <span>دسته: </span>
                        <?php
                        $cats = get_the_terms($product->ID , 'product_cat');
                        ?>
                        <a href="<?php echo get_term_link($cats[0]->term_id); ?>" target="_blank"><?php echo $cats[0]->name; ?></a>
                    </div>
                    <?php } ?>
                    <?php if (get_field('quarantee')) : ?>
                    <div class="meta-pro">
                        <i class="fa-solid fa-sun"></i>
                        <span><?php the_field('quarantee'); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="product-delivery">
                <?php if (get_field('delivery1')) : ?>
                <span>
                    <i class="fa-solid fa-paper-plane"></i>
                    <?php the_field('delivery1'); ?>
                </span>
                <?php endif; ?>
                <?php if (get_field('delivery2')) : ?>
                <span>
                    <i class="fa-solid fa-circle-dot"></i>
                    <?php the_field('delivery2'); ?>
                </span>
                <?php endif; ?>
            </div>

            <?php if ($options['active_excerpt_content']) { ?>
            <div class="excerpt_single_product"><?php the_excerpt(); ?></div>
            <?php } ?>
            <?php if ($options['active_attr']) { ?>
            <?php do_action( 'woocommerce_product_additional_information', $product ); ?>
            <?php } ?>

            <?php if ($product->is_type('simple')) : ?>
            <div class="show-rate">
            <?php woocommerce_template_single_rating(); ?>
            </div>
            <?php endif; ?>

            <?php woocommerce_template_single_add_to_cart(); ?>


            <?php
            /**
             * Hook: woocommerce_single_product_summary.
             *
             * @hooked woocommerce_template_single_title - 5
             * @hooked woocommerce_template_single_rating - 10
             * @hooked woocommerce_template_single_price - 10
             * @hooked woocommerce_template_single_excerpt - 20
             * @hooked woocommerce_template_single_add_to_cart - 30
             * @hooked woocommerce_template_single_meta - 40
             * @hooked woocommerce_template_single_sharing - 50
             * @hooked WC_Structured_Data::generate_product_data() - 60
             */
            //do_action( 'woocommerce_single_product_summary' );
            ?>
        </div>
	<?php
	/**
	 * Hook: woocommerce_before_single_product_summary.
	 *
	 * @hooked woocommerce_show_product_sale_flash - 10
	 * @hooked woocommerce_show_product_images - 20
	 */
	do_action( 'woocommerce_before_single_product_summary' );
	?>


    </section>
	<?php
	/**
	 * Hook: woocommerce_after_single_product_summary.
	 *
	 * @hooked woocommerce_output_product_data_tabs - 10
	 * @hooked woocommerce_upsell_display - 15
	 * @hooked woocommerce_output_related_products - 20
	 */
	do_action( 'woocommerce_after_single_product_summary' );
	?>
    <?php if ($options['active_related_product']) { ?>
    <?php echo do_shortcode('[related_products]'); ?>
    <?php } ?>
</div>

<?php do_action( 'woocommerce_after_single_product' ); ?>
